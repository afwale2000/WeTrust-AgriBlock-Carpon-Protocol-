import { FarmerProfile, FarmingProject, CarbonCertificate, BlockchainBlock, RewardPayout } from '../types';

export const INITIAL_FARMERS: FarmerProfile[] = [
  {
    id: 'farmer-01',
    name: 'Samuel Green',
    email: 'samuel.green@agrifarm.org',
    farmName: 'Verdant Horizon Acres',
    location: 'Iowa, USA (Corn Belt)',
    coordinates: { lat: 41.878, lng: -93.097 },
    totalAcreage: 450,
    cropTypes: ['Corn', 'Soybeans', 'Winter Rye Cover Crop'],
    walletAddress: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
    creditsBalance: 180,
    rewardTokensBalance: 21600,
    usdtBalance: 4320
  },
  {
    id: 'farmer-02',
    name: 'Elena Rostova',
    email: 'elena.rostova@ecoagri.io',
    farmName: 'Sunland Regenerative Farm',
    location: 'Mendoza, Argentina',
    coordinates: { lat: -32.889, lng: -68.845 },
    totalAcreage: 320,
    cropTypes: ['Vineyards', 'Olive Groves', 'Legume Ground Cover'],
    walletAddress: '0x3F28c89280d59A083d9943B06fF99C3119106E1A',
    creditsBalance: 125,
    rewardTokensBalance: 15000,
    usdtBalance: 3000
  },
  {
    id: 'farmer-03',
    name: 'Amina Kwame',
    email: 'amina.k@agroforest.org',
    farmName: 'Kilimanjaro Agroforestry Cooperative',
    location: 'Arusha, Tanzania',
    coordinates: { lat: -3.386, lng: 36.682 },
    totalAcreage: 180,
    cropTypes: ['Coffee', 'Bananas', 'Acacia Shade Trees'],
    walletAddress: '0x9B12e34D210985223eC323aA110822Dca9876aB0',
    creditsBalance: 210,
    rewardTokensBalance: 27300,
    usdtBalance: 5460
  }
];

export const INITIAL_PROJECTS: FarmingProject[] = [
  {
    id: 'PRJ-2026-001',
    farmerId: 'farmer-01',
    farmerName: 'Samuel Green',
    farmName: 'Verdant Horizon Acres',
    location: 'Iowa, USA',
    coordinates: { lat: 41.878, lng: -93.097 },
    areaHectares: 182,
    primaryPractice: 'no_till',
    additionalPractices: ['cover_cropping', 'water_conservation'],
    startDate: '2025-03-15',
    soilType: 'Mollisol (Deep Silty Clay Loam)',
    fertilizerReductionPercent: 28,
    evidenceDocs: ['soil_test_soc_2025.pdf', 'satellite_ndvi_march.png', 'tillage_equipment_log.json'],
    status: 'certified',
    assessmentResult: {
      baselineEmissions: 412,
      projectEmissions: 232,
      grossSequestration: 180,
      netCarbonCreditsYield: 180,
      aiConfidenceScore: 94,
      methodologyStandard: 'IPCC Tier 2 / Verra VM0042 / ESP Agriculture Standard',
      espCompliance: {
        soilOrganicCarbonScore: 92,
        waterConservationScore: 88,
        biodiversityIndexScore: 85,
        socialEquityScore: 95,
        permanenceRiskScore: 90,
        totalESPScore: 90,
        espTier: 'Gold',
        meetsESPCriteria: true,
        complianceNotes: [
          'High soil organic carbon retention verified via Landsat 9 NDVI analysis.',
          'Zero chemical runoff into regional watershed confirmed.',
          'Fair compensation wage compliance verified for farm laborers.'
        ]
      },
      keyInsights: [
        'No-till combined with Winter Rye cover crops increased active SOC by 0.38% year-over-year.',
        'Nitrous oxide (N2O) soil emissions reduced by 32% due to controlled-release bio-fertilizer usage.'
      ],
      recommendedImprovements: [
        'Incorporate rotational legume nitrogen fixation in sector 4 to unlock additional 15 tCO2e potential.'
      ],
      assessmentDate: '2026-01-10'
    },
    auditRecord: {
      id: 'AUD-8821',
      projectId: 'PRJ-2026-001',
      auditorName: 'Dr. Marcus Vance',
      auditorOrg: 'Global Carbon Audit Consortium (GCAC)',
      auditorWallet: '0x88f2190A98032d15A019bC398188C02B90c3A08',
      auditTimestamp: '2026-01-18T14:32:00Z',
      status: 'approved',
      criteriaChecks: {
        baselineValidated: true,
        espComplianceVerified: true,
        satelliteImageryMatched: true,
        noDoubleCounting: true,
        additionalityProven: true
      },
      auditorNotes: 'On-site core soil sampling matches satellite radar backscatter metrics. Full compliance with ESP Gold standards.',
      signatureHash: '0x99281a8c9b20e181827c191a82910d82937812918237198a2873812128e'
    },
    certificateHash: '0x3a2e91b8a21f7c89d023b1827aef92138a01f9c82b1239841283e712390a12fe',
    createdAt: '2025-11-01'
  },
  {
    id: 'PRJ-2026-002',
    farmerId: 'farmer-03',
    farmerName: 'Amina Kwame',
    farmName: 'Kilimanjaro Agroforestry Cooperative',
    location: 'Arusha, Tanzania',
    coordinates: { lat: -3.386, lng: 36.682 },
    areaHectares: 73,
    primaryPractice: 'agroforestry',
    additionalPractices: ['organic_fertilizer', 'water_conservation'],
    startDate: '2025-01-20',
    soilType: 'Andisol (Volcanic Ash Soils)',
    fertilizerReductionPercent: 45,
    evidenceDocs: ['canopy_tree_count_survey.pdf', 'coop_fair_trade_cert.pdf'],
    status: 'certified',
    assessmentResult: {
      baselineEmissions: 310,
      projectEmissions: 100,
      grossSequestration: 210,
      netCarbonCreditsYield: 210,
      aiConfidenceScore: 96,
      methodologyStandard: 'IPCC Tier 2 Agroforestry Biomass Model v4.1',
      espCompliance: {
        soilOrganicCarbonScore: 96,
        waterConservationScore: 94,
        biodiversityIndexScore: 98,
        socialEquityScore: 98,
        permanenceRiskScore: 92,
        totalESPScore: 96,
        espTier: 'Gold',
        meetsESPCriteria: true,
        complianceNotes: [
          'High shade-canopy biodiversity index (+42 indigenous species recorded).',
          'Community cooperative profit sharing model meets top ESP social inclusion criteria.'
        ]
      },
      keyInsights: [
        'Shade tree canopy biomass sequestration accounts for 145 tCO2e.',
        'Soil organic matter boosted from 2.1% to 3.8% over 18 months.'
      ],
      recommendedImprovements: [
        'Expand biochar pyrolyzer adoption across community post-harvest waste.'
      ],
      assessmentDate: '2026-02-01'
    },
    auditRecord: {
      id: 'AUD-8822',
      projectId: 'PRJ-2026-002',
      auditorName: 'Sophia Lin, Lead Auditor',
      auditorOrg: 'EcoAudit Verifiers Intl.',
      auditorWallet: '0x1A2b3C4d5E6f7G8h9I0j1K2l3M4n5O6p7Q8r9S0t',
      auditTimestamp: '2026-02-05T10:15:00Z',
      status: 'approved',
      criteriaChecks: {
        baselineValidated: true,
        espComplianceVerified: true,
        satelliteImageryMatched: true,
        noDoubleCounting: true,
        additionalityProven: true
      },
      auditorNotes: 'High biodiversity biomass sequestration. Additionality and social benefits verified.',
      signatureHash: '0x8817263b1298c1928371982739182391283912839128312938123912389123'
    },
    certificateHash: '0x77c829e1823901a28391823918239182391823912839123891239182391238',
    createdAt: '2025-12-10'
  },
  {
    id: 'PRJ-2026-003',
    farmerId: 'farmer-02',
    farmerName: 'Elena Rostova',
    farmName: 'Sunland Regenerative Farm',
    location: 'Mendoza, Argentina',
    coordinates: { lat: -32.889, lng: -68.845 },
    areaHectares: 129,
    primaryPractice: 'rotational_grazing',
    additionalPractices: ['cover_cropping', 'biochar_application'],
    startDate: '2025-06-01',
    soilType: 'Aridisol / Alluvial Silt',
    fertilizerReductionPercent: 35,
    evidenceDocs: ['grazing_rotation_schedule.pdf', 'biochar_kiln_cert.pdf'],
    status: 'pending_audit',
    assessmentResult: {
      baselineEmissions: 280,
      projectEmissions: 155,
      grossSequestration: 125,
      netCarbonCreditsYield: 125,
      aiConfidenceScore: 89,
      methodologyStandard: 'IPCC Tier 2 Soil & Livestock Management',
      espCompliance: {
        soilOrganicCarbonScore: 84,
        waterConservationScore: 81,
        biodiversityIndexScore: 80,
        socialEquityScore: 88,
        permanenceRiskScore: 82,
        totalESPScore: 83,
        espTier: 'Silver',
        meetsESPCriteria: true,
        complianceNotes: [
          'Holistic livestock management verified via satellite herd tracking.',
          'Local water aquifer extraction rate monitored within sustainable limits.'
        ]
      },
      keyInsights: [
        'Short-duration high-density grazing improved root depth penetration by 14cm.',
        'Biochar soil amendment added 22 tCO2e long-term carbon lock.'
      ],
      recommendedImprovements: [
        'Add leguminous ground cover to reduce synthetic nitrogen supplementation further.'
      ],
      assessmentDate: '2026-03-01'
    },
    createdAt: '2026-02-15'
  }
];

export const INITIAL_CERTIFICATES: CarbonCertificate[] = [
  {
    certificateId: 'CERT-2026-AGRI-8832',
    projectId: 'PRJ-2026-001',
    farmerId: 'farmer-01',
    farmerName: 'Samuel Green',
    farmName: 'Verdant Horizon Acres',
    location: 'Iowa, USA',
    tonsCO2e: 180,
    issueDate: '2026-01-20',
    expirationDate: '2031-01-20',
    espBadge: 'Gold Standard ESP',
    certificateHash: '0x3a2e91b8a21f7c89d023b1827aef92138a01f9c82b1239841283e712390a12fe',
    blockNumber: 1042,
    transactionHash: '0x99281a8c9b20e181827c191a82910d82937812918237198a2873812128e',
    status: 'active',
    ownedByWallet: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F'
  },
  {
    certificateId: 'CERT-2026-AGRI-9910',
    projectId: 'PRJ-2026-002',
    farmerId: 'farmer-03',
    farmerName: 'Amina Kwame',
    farmName: 'Kilimanjaro Agroforestry Cooperative',
    location: 'Arusha, Tanzania',
    tonsCO2e: 210,
    issueDate: '2026-02-08',
    expirationDate: '2031-02-08',
    espBadge: 'Gold Standard ESP',
    certificateHash: '0x77c829e1823901a28391823918239182391823912839123891239182391238',
    blockNumber: 1088,
    transactionHash: '0x8817263b1298c1928371982739182391283912839128312938123912389123',
    status: 'active',
    ownedByWallet: '0x9B12e34D210985223eC323aA110822Dca9876aB0'
  }
];

export const INITIAL_BLOCKS: BlockchainBlock[] = [
  {
    index: 1042,
    timestamp: '2026-01-20T11:20:00Z',
    previousHash: '0x000882190a827182910283918293819283918239128391283912839182391238',
    hash: '0x0001a88b2910a283918239182391823918239128391283912839128391283912',
    nonce: 142,
    merkleRoot: '0x3a2e91b8a21f7c89d023b1827aef92138a01f9c82b1239841283e712390a12fe',
    validatorNode: 'AgriBlock-ESP-Validator-Alpha',
    transactions: [
      {
        txHash: '0x99281a8c9b20e181827c191a82910d82937812918237198a2873812128e',
        blockNumber: 1042,
        type: 'MINT_CERTIFICATE',
        fromAddress: '0x0000000000000000000000000000000000000000',
        toAddress: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
        payload: {
          certificateId: 'CERT-2026-AGRI-8832',
          farmerName: 'Samuel Green',
          tonsCO2e: 180,
          espTier: 'Gold'
        },
        timestamp: '2026-01-20T11:19:45Z',
        gasUsed: 42100,
        status: 'mined'
      },
      {
        txHash: '0x229817291a2819283918239128391823912839128391283912839128391283',
        blockNumber: 1042,
        type: 'CLAIM_REWARD',
        fromAddress: '0xAgriBlockProtocolTreasury',
        toAddress: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
        payload: {
          rewardTokens: 21600,
          farmerId: 'farmer-01',
          usdEquivalent: 4320
        },
        timestamp: '2026-01-20T11:20:00Z',
        gasUsed: 21000,
        status: 'mined'
      }
    ]
  },
  {
    index: 1088,
    timestamp: '2026-02-08T15:40:00Z',
    previousHash: '0x0001a88b2910a283918239182391823918239128391283912839128391283912',
    hash: '0x000298172910a827182910283918293819283918239128391283912839128391',
    nonce: 88,
    merkleRoot: '0x77c829e1823901a28391823918239182391823912839123891239182391238',
    validatorNode: 'AgriBlock-Auditor-Node-Beta',
    transactions: [
      {
        txHash: '0x8817263b1298c1928371982739182391283912839128312938123912389123',
        blockNumber: 1088,
        type: 'MINT_CERTIFICATE',
        fromAddress: '0x0000000000000000000000000000000000000000',
        toAddress: '0x9B12e34D210985223eC323aA110822Dca9876aB0',
        payload: {
          certificateId: 'CERT-2026-AGRI-9910',
          farmerName: 'Amina Kwame',
          tonsCO2e: 210,
          espTier: 'Gold'
        },
        timestamp: '2026-02-08T15:39:20Z',
        gasUsed: 42100,
        status: 'mined'
      }
    ]
  }
];

export const INITIAL_PAYOUTS: RewardPayout[] = [
  {
    id: 'PAY-1001',
    farmerId: 'farmer-01',
    farmerName: 'Samuel Green',
    projectId: 'PRJ-2026-001',
    carbonTons: 180,
    baseRewardTokens: 18000,
    espBonusTokens: 3600, // 20% Gold ESP bonus
    totalTokens: 21600,
    usdEquivalent: 4320,
    timestamp: '2026-01-20T11:20:00Z',
    txHash: '0x229817291a2819283918239128391823912839128391283912839128391283',
    claimed: true
  },
  {
    id: 'PAY-1002',
    farmerId: 'farmer-03',
    farmerName: 'Amina Kwame',
    projectId: 'PRJ-2026-002',
    carbonTons: 210,
    baseRewardTokens: 21000,
    espBonusTokens: 6300, // 30% Gold ESP + Agroforestry bonus
    totalTokens: 27300,
    usdEquivalent: 5460,
    timestamp: '2026-02-08T15:40:00Z',
    txHash: '0x8817263b1298c1928371982739182391283912839128312938123912389123',
    claimed: true
  }
];
