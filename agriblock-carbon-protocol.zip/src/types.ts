export type UserRole = 'farmer' | 'auditor' | 'esp_officer' | 'buyer' | 'public';

export type FarmingPractice = 
  | 'no_till' 
  | 'cover_cropping' 
  | 'agroforestry' 
  | 'biochar_application' 
  | 'rotational_grazing' 
  | 'organic_fertilizer' 
  | 'water_conservation';

export interface FarmerProfile {
  id: string;
  name: string;
  email: string;
  farmName: string;
  location: string;
  coordinates: { lat: number; lng: number };
  totalAcreage: number; // in acres
  cropTypes: string[];
  walletAddress: string;
  creditsBalance: number; // tCO2e
  rewardTokensBalance: number; // $AGRI-CO2
  usdtBalance: number;
}

export interface ESPCompliance {
  soilOrganicCarbonScore: number; // 0-100
  waterConservationScore: number; // 0-100
  biodiversityIndexScore: number; // 0-100
  socialEquityScore: number; // 0-100
  permanenceRiskScore: number; // 0-100 (higher is better risk mitigation)
  totalESPScore: number; // 0-100
  espTier: 'Gold' | 'Silver' | 'Bronze' | 'Non-Compliant';
  meetsESPCriteria: boolean;
  complianceNotes: string[];
}

export interface CarbonAssessmentResult {
  baselineEmissions: number; // tCO2e/year
  projectEmissions: number; // tCO2e/year
  grossSequestration: number; // tCO2e/year
  netCarbonCreditsYield: number; // tCO2e/year
  aiConfidenceScore: number; // 0-100%
  methodologyStandard: string; // e.g., "IPCC Tier 2 / Verra VM0042 / ESP Framework"
  espCompliance: ESPCompliance;
  keyInsights: string[];
  recommendedImprovements: string[];
  assessmentDate: string;
}

export type ProjectStatus = 
  | 'draft' 
  | 'pending_assessment' 
  | 'ai_verified' 
  | 'pending_audit' 
  | 'certified' 
  | 'rejected';

export interface FarmingProject {
  id: string;
  farmerId: string;
  farmerName: string;
  farmName: string;
  location: string;
  coordinates: { lat: number; lng: number };
  areaHectares: number;
  primaryPractice: FarmingPractice;
  additionalPractices: FarmingPractice[];
  startDate: string;
  soilType: string;
  fertilizerReductionPercent: number;
  evidenceDocs: string[];
  status: ProjectStatus;
  assessmentResult?: CarbonAssessmentResult;
  auditRecord?: AuditRecord;
  certificateHash?: string;
  createdAt: string;
}

export interface AuditRecord {
  id: string;
  projectId: string;
  auditorName: string;
  auditorOrg: string;
  auditorWallet: string;
  auditTimestamp: string;
  status: 'approved' | 'rejected' | 'flagged';
  criteriaChecks: {
    baselineValidated: boolean;
    espComplianceVerified: boolean;
    satelliteImageryMatched: boolean;
    noDoubleCounting: boolean;
    additionalityProven: boolean;
  };
  auditorNotes: string;
  signatureHash: string;
}

export interface CarbonCertificate {
  certificateId: string; // e.g., CERT-2026-AGRI-8832
  projectId: string;
  farmerId: string;
  farmerName: string;
  farmName: string;
  location: string;
  tonsCO2e: number;
  issueDate: string;
  expirationDate: string;
  espBadge: 'Gold Standard ESP' | 'Silver ESP' | 'Bronze ESP';
  certificateHash: string; // SHA-256 Merkle root proof
  blockNumber: number;
  transactionHash: string;
  status: 'active' | 'transferred' | 'retired';
  ownedByWallet: string;
  retiredForCompany?: string;
}

export type TransactionType = 
  | 'REGISTER_FARM' 
  | 'SUBMIT_ASSESSMENT' 
  | 'AUDITOR_APPROVAL' 
  | 'MINT_CERTIFICATE' 
  | 'CLAIM_REWARD' 
  | 'BUY_CREDITS' 
  | 'RETIRE_CREDITS';

export interface BlockchainTransaction {
  txHash: string;
  blockNumber: number;
  type: TransactionType;
  fromAddress: string;
  toAddress: string;
  payload: Record<string, any>;
  timestamp: string;
  gasUsed: number;
  status: 'mined' | 'pending';
}

export interface BlockchainBlock {
  index: number;
  timestamp: string;
  transactions: BlockchainTransaction[];
  previousHash: string;
  hash: string;
  nonce: number;
  merkleRoot: string;
  validatorNode: string;
}

export interface RewardPayout {
  id: string;
  farmerId: string;
  farmerName: string;
  projectId: string;
  carbonTons: number;
  baseRewardTokens: number; // $AGRI-CO2
  espBonusTokens: number; // $AGRI-CO2 bonus for ESP high tier
  totalTokens: number;
  usdEquivalent: number;
  timestamp: string;
  txHash: string;
  claimed: boolean;
}
