import React, { useState } from 'react';
import { UserRole, FarmerProfile, FarmingProject, CarbonCertificate, BlockchainBlock, RewardPayout, AuditRecord } from './types';
import { INITIAL_FARMERS, INITIAL_PROJECTS, INITIAL_CERTIFICATES, INITIAL_BLOCKS, INITIAL_PAYOUTS } from './data/initialData';
import { generateCertificateHash, createBlock } from './lib/blockchain';
import { Navbar } from './components/Navbar';
import { FarmerPortal } from './components/FarmerPortal';
import { AuditPortal } from './components/AuditPortal';
import { RewardMarket } from './components/RewardMarket';
import { BlockchainExplorer } from './components/BlockchainExplorer';
import { CarbonAssessmentView } from './components/CarbonAssessmentView';

export default function App() {
  const [currentRole, setCurrentRole] = useState<UserRole>('farmer');
  const [activeTab, setActiveTab] = useState<string>('farmer');
  
  // State
  const [farmers, setFarmers] = useState<FarmerProfile[]>(INITIAL_FARMERS);
  const [activeFarmer, setActiveFarmer] = useState<FarmerProfile>(INITIAL_FARMERS[0]);
  const [projects, setProjects] = useState<FarmingProject[]>(INITIAL_PROJECTS);
  const [certificates, setCertificates] = useState<CarbonCertificate[]>(INITIAL_CERTIFICATES);
  const [blocks, setBlocks] = useState<BlockchainBlock[]>(INITIAL_BLOCKS);
  const [payouts, setPayouts] = useState<RewardPayout[]>(INITIAL_PAYOUTS);

  // Detail view state
  const [selectedProjectForDetail, setSelectedProjectForDetail] = useState<FarmingProject | null>(null);

  // Handle New Farming Project Creation (From AI Assessment Wizard)
  const handleCreateProject = (newProject: FarmingProject) => {
    setProjects([newProject, ...projects]);
  };

  // Handle Auditor Sign-off and On-Chain Certificate Minting
  const handleApproveAndMint = async (projectId: string, auditRecord: AuditRecord) => {
    const project = projects.find(p => p.id === projectId);
    if (!project || !project.assessmentResult) return;

    const certId = `CERT-2026-AGRI-${Math.floor(1000 + Math.random() * 9000)}`;
    const tons = project.assessmentResult.netCarbonCreditsYield;
    const espScore = project.assessmentResult.espCompliance.totalESPScore;
    const issueDate = new Date().toISOString().split('T')[0];

    const certHash = await generateCertificateHash(
      certId,
      project.farmerId,
      tons,
      espScore,
      issueDate
    );

    const farmer = farmers.find(f => f.id === project.farmerId);

    // Create Blockchain Transaction & Mine Block
    const nextBlockIndex = (blocks[blocks.length - 1]?.index || 1088) + 1;
    const prevHash = blocks[blocks.length - 1]?.hash || '0x000298172910a827182910283918293819283918239128391283912839128391';

    const mintTxHash = `0x${Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('')}`;
    const claimTxHash = `0x${Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('')}`;

    const newBlock = await createBlock(
      nextBlockIndex,
      prevHash,
      [
        {
          txHash: mintTxHash,
          blockNumber: nextBlockIndex,
          type: 'MINT_CERTIFICATE',
          fromAddress: '0x0000000000000000000000000000000000000000',
          toAddress: farmer?.walletAddress || '0xFarmerWallet',
          payload: {
            certificateId: certId,
            farmerName: project.farmerName,
            tonsCO2e: tons,
            espTier: project.assessmentResult.espCompliance.espTier
          },
          timestamp: new Date().toISOString(),
          gasUsed: 42100,
          status: 'mined'
        },
        {
          txHash: claimTxHash,
          blockNumber: nextBlockIndex,
          type: 'CLAIM_REWARD',
          fromAddress: '0xAgriBlockProtocolTreasury',
          toAddress: farmer?.walletAddress || '0xFarmerWallet',
          payload: {
            rewardTokens: tons * 120,
            farmerId: project.farmerId,
            usdEquivalent: tons * 24
          },
          timestamp: new Date().toISOString(),
          gasUsed: 21000,
          status: 'mined'
        }
      ],
      'AgriBlock-Consortium-Node-1'
    );

    // Update Certificate list
    const newCert: CarbonCertificate = {
      certificateId: certId,
      projectId: project.id,
      farmerId: project.farmerId,
      farmerName: project.farmerName,
      farmName: project.farmName,
      location: project.location,
      tonsCO2e: tons,
      issueDate,
      expirationDate: '2031-01-01',
      espBadge: project.assessmentResult.espCompliance.espTier === 'Gold' 
        ? 'Gold Standard ESP' 
        : project.assessmentResult.espCompliance.espTier === 'Silver' 
        ? 'Silver ESP' 
        : 'Bronze ESP',
      certificateHash: certHash,
      blockNumber: nextBlockIndex,
      transactionHash: mintTxHash,
      status: 'active',
      ownedByWallet: farmer?.walletAddress || '0xFarmerWallet'
    };

    // Update Payout record
    const baseTokens = tons * 100;
    const bonusTokens = Math.round(baseTokens * (espScore >= 90 ? 0.20 : 0.10));
    const totalTokens = baseTokens + bonusTokens;

    const newPayout: RewardPayout = {
      id: `PAY-${Date.now().toString().slice(-4)}`,
      farmerId: project.farmerId,
      farmerName: project.farmerName,
      projectId: project.id,
      carbonTons: tons,
      baseRewardTokens: baseTokens,
      espBonusTokens: bonusTokens,
      totalTokens,
      usdEquivalent: tons * 24,
      timestamp: new Date().toISOString(),
      txHash: claimTxHash,
      claimed: true
    };

    // Update Projects status to certified
    const updatedProjects = projects.map(p => {
      if (p.id === projectId) {
        return {
          ...p,
          status: 'certified' as const,
          auditRecord,
          certificateHash: certHash
        };
      }
      return p;
    });

    // Update Farmer wallet balance
    const updatedFarmers = farmers.map(f => {
      if (f.id === project.farmerId) {
        return {
          ...f,
          creditsBalance: f.creditsBalance + tons,
          rewardTokensBalance: f.rewardTokensBalance + totalTokens,
          usdtBalance: f.usdtBalance + (tons * 24)
        };
      }
      return f;
    });

    setBlocks([...blocks, newBlock]);
    setCertificates([newCert, ...certificates]);
    setPayouts([newPayout, ...payouts]);
    setProjects(updatedProjects);
    setFarmers(updatedFarmers);

    // If active farmer matches, update active farmer state
    if (activeFarmer.id === project.farmerId) {
      const currentActive = updatedFarmers.find(f => f.id === project.farmerId);
      if (currentActive) setActiveFarmer(currentActive);
    }

    if (selectedProjectForDetail?.id === projectId) {
      setSelectedProjectForDetail({
        ...selectedProjectForDetail,
        status: 'certified',
        auditRecord,
        certificateHash: certHash
      });
    }
  };

  // Handle Certificate Retirement for Net-Zero Offset
  const handleRetireCertificate = (certificateId: string, companyName: string) => {
    setCertificates(certificates.map(c => {
      if (c.certificateId === certificateId) {
        return {
          ...c,
          status: 'retired',
          retiredForCompany: companyName
        };
      }
      return c;
    }));
  };

  // Handle Buying Carbon Credit Token
  const handleBuyCertificate = (certificateId: string, buyerWallet: string) => {
    setCertificates(certificates.map(c => {
      if (c.certificateId === certificateId) {
        return {
          ...c,
          ownedByWallet: buyerWallet
        };
      }
      return c;
    }));
    alert(`Successfully purchased Certificate ${certificateId}! Transfer recorded on AgriBlock Mainnet.`);
  };

  return (
    <div className="min-h-screen bg-[#F7F9F4] text-[#2D3B2D] flex flex-col font-sans selection:bg-[#4F6D4F] selection:text-white">
      
      {/* Top Navbar */}
      <Navbar
        currentRole={currentRole}
        onSelectRole={role => setCurrentRole(role)}
        activeFarmer={activeFarmer}
        onSelectFarmer={f => setActiveFarmer(f)}
        farmers={farmers}
        blockCount={blocks.length}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Content View Switcher */}
      <main className="flex-grow">
        {selectedProjectForDetail ? (
          <CarbonAssessmentView
            project={selectedProjectForDetail}
            onBack={() => setSelectedProjectForDetail(null)}
            onApproveByAuditor={projectId => {
              const auditRec: AuditRecord = {
                id: `AUD-${Math.floor(1000 + Math.random() * 9000)}`,
                projectId,
                auditorName: 'Dr. Marcus Vance',
                auditorOrg: 'Global Carbon Audit Consortium',
                auditorWallet: '0x88f2190A98032d15A019bC398188C02B90c3A08',
                auditTimestamp: new Date().toISOString(),
                status: 'approved',
                criteriaChecks: {
                  baselineValidated: true,
                  espComplianceVerified: true,
                  satelliteImageryMatched: true,
                  noDoubleCounting: true,
                  additionalityProven: true
                },
                auditorNotes: 'Direct validation of satellite radar telemetry & ESP soil standards.',
                signatureHash: '0x88271a82910a827182910283918293819283918239128391283912839128391'
              };
              handleApproveAndMint(projectId, auditRec);
            }}
            isAuditorView={currentRole === 'auditor' || activeTab === 'audit'}
          />
        ) : (
          <>
            {activeTab === 'farmer' && (
              <FarmerPortal
                activeFarmer={activeFarmer}
                projects={projects}
                onCreateProject={handleCreateProject}
                onClaimReward={(pid, amt) => alert(`Reward claimed for project ${pid}`)}
                onSelectProjectForView={prj => setSelectedProjectForDetail(prj)}
              />
            )}

            {activeTab === 'audit' && (
              <AuditPortal
                projects={projects}
                onApproveAndMint={handleApproveAndMint}
                onSelectProjectForView={prj => setSelectedProjectForDetail(prj)}
              />
            )}

            {activeTab === 'rewards' && (
              <RewardMarket
                certificates={certificates}
                payouts={payouts}
                activeFarmer={activeFarmer}
                onRetireCertificate={handleRetireCertificate}
                onBuyCertificate={handleBuyCertificate}
              />
            )}

            {activeTab === 'explorer' && (
              <BlockchainExplorer
                blocks={blocks}
                certificates={certificates}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-[#E2E8DA] py-6 px-4 text-center text-xs text-[#5E7E5E]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-semibold text-[#2D3B2D]">
            © 2026 TerraTrust / AgriBlock Carbon Protocol. ESP (Environmental & Social Performance) Standards.
          </p>
          <div className="flex items-center space-x-4 text-[11px] font-mono text-[#4F6D4F]">
            <span>Mainnet Block #{blocks[blocks.length - 1]?.index}</span>
            <span>•</span>
            <span className="text-[#365336] font-bold">Consortium Consensus Active ✓</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
