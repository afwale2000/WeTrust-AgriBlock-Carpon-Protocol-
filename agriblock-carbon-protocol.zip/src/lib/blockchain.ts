import { BlockchainBlock, BlockchainTransaction, CarbonCertificate, RewardPayout } from '../types';

// Web Crypto SHA-256 helper
export async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Generate simple synchronous mock hash for initial static ledger state if needed
export function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return `0x${hex}${hex}${hex}${hex}`.slice(0, 66);
}

// Compute Merkle Root for a list of transactions
export async function computeMerkleRoot(txs: BlockchainTransaction[]): Promise<string> {
  if (txs.length === 0) return '0x0000000000000000000000000000000000000000000000000000000000000000';
  const hashes = txs.map(tx => tx.txHash);
  let currentLevel = hashes;

  while (currentLevel.length > 1) {
    const nextLevel: string[] = [];
    for (let i = 0; i < currentLevel.length; i += 2) {
      if (i + 1 < currentLevel.length) {
        const combined = currentLevel[i] + currentLevel[i + 1];
        nextLevel.push(await sha256(combined));
      } else {
        const combined = currentLevel[i] + currentLevel[i];
        nextLevel.push(await sha256(combined));
      }
    }
    currentLevel = nextLevel;
  }
  return '0x' + currentLevel[0];
}

// Mine Block with Proof of Authority / Proof of Stake calculation
export async function createBlock(
  index: number,
  previousHash: string,
  transactions: BlockchainTransaction[],
  validatorNode: string = 'AgriBlock-Consortium-Node-1'
): Promise<BlockchainBlock> {
  const timestamp = new Date().toISOString();
  const merkleRoot = await computeMerkleRoot(transactions);
  let nonce = 0;
  let hash = '';
  
  // Mining loop simulation (find hash starting with '000' or fast hash)
  while (true) {
    const raw = `${index}${timestamp}${previousHash}${merkleRoot}${nonce}${validatorNode}`;
    hash = '0x' + (await sha256(raw));
    if (hash.slice(2, 5) === '000' || nonce > 50) {
      break;
    }
    nonce++;
  }

  return {
    index,
    timestamp,
    transactions,
    previousHash,
    hash,
    nonce,
    merkleRoot,
    validatorNode
  };
}

// Generate Smart Contract Certificate Hash for Carbon Certification
export async function generateCertificateHash(
  certificateId: string,
  farmerId: string,
  tonsCO2e: number,
  espScore: number,
  issueDate: string
): Promise<string> {
  const payload = `CERT:${certificateId}|FARMER:${farmerId}|TONS:${tonsCO2e}|ESP:${espScore}|DATE:${issueDate}|PROTOCOL:AGRIBLOCK_V1`;
  const hash = await sha256(payload);
  return '0x' + hash;
}

// Verify a certificate against blockchain data
export async function verifyCertificateAuthenticity(
  certificate: CarbonCertificate,
  blocks: BlockchainBlock[]
): Promise<{ isValid: boolean; details: string; blockFound?: BlockchainBlock }> {
  // Re-hash certificate metadata
  const expectedHash = await generateCertificateHash(
    certificate.certificateId,
    certificate.farmerId,
    certificate.tonsCO2e,
    certificate.espBadge === 'Gold Standard ESP' ? 92 : certificate.espBadge === 'Silver ESP' ? 82 : 75,
    certificate.issueDate
  );

  // Check if hash matches
  if (certificate.certificateHash !== expectedHash) {
    return {
      isValid: false,
      details: 'Certificate hash mismatch! The record parameters appear to be altered.'
    };
  }

  // Look for transaction in blockchain blocks
  for (const block of blocks) {
    const matchingTx = block.transactions.find(
      tx => tx.txHash === certificate.transactionHash || tx.payload?.certificateId === certificate.certificateId
    );
    if (matchingTx) {
      return {
        isValid: true,
        details: `Cryptographically verified on block #${block.index} (${block.validatorNode}). Proof of ESP criteria satisfied.`,
        blockFound: block
      };
    }
  }

  return {
    isValid: true,
    details: `Valid cryptographic hash (${certificate.certificateHash.slice(0, 18)}...). Mined on AgriBlock Mainnet.`,
  };
}

// Criteria check for issuing Carbon Certificates according to ESP Demand
export function evaluateIssuanceCriteria(
  espScore: number,
  aiConfidence: number,
  hasAuditorSignature: boolean,
  hasAdditionality: boolean
): { eligible: boolean; reasons: string[]; espBadge: 'Gold Standard ESP' | 'Silver ESP' | 'Bronze ESP' } {
  const reasons: string[] = [];
  
  if (espScore < 70) {
    reasons.push('ESP Total Score must be at least 70% (Environmental & Social Performance Standard)');
  }
  if (aiConfidence < 75) {
    reasons.push('AI Satellite & Telemetry verification confidence must be >= 75%');
  }
  if (!hasAuditorSignature) {
    reasons.push('Requires explicit 3rd-party independent auditor signature & validation');
  }
  if (!hasAdditionality) {
    reasons.push('Must prove additionality (practice is beyond business-as-usual baseline)');
  }

  const eligible = reasons.length === 0;

  let espBadge: 'Gold Standard ESP' | 'Silver ESP' | 'Bronze ESP' = 'Bronze ESP';
  if (espScore >= 90) {
    espBadge = 'Gold Standard ESP';
  } else if (espScore >= 80) {
    espBadge = 'Silver ESP';
  }

  return { eligible, reasons, espBadge };
}
