import React, { useState } from 'react';
import { CarbonCertificate, RewardPayout, FarmerProfile } from '../types';
import { 
  Coins, 
  TrendingUp, 
  Award, 
  ShoppingCart, 
  Flame, 
  CheckCircle2, 
  ExternalLink, 
  PieChart, 
  ShieldCheck, 
  ArrowRightLeft,
  Building,
  Sparkles,
  Search
} from 'lucide-react';

interface RewardMarketProps {
  certificates: CarbonCertificate[];
  payouts: RewardPayout[];
  activeFarmer: FarmerProfile;
  onRetireCertificate: (certificateId: string, companyName: string) => void;
  onBuyCertificate: (certificateId: string, buyerWallet: string) => void;
}

export const RewardMarket: React.FC<RewardMarketProps> = ({
  certificates,
  payouts,
  activeFarmer,
  onRetireCertificate,
  onBuyCertificate
}) => {
  const [retireCompanyName, setRetireCompanyName] = useState('EcoTech Solutions Corp.');
  const [selectedCertForRetire, setSelectedCertForRetire] = useState<CarbonCertificate | null>(null);
  const [activeTab, setActiveTab] = useState<'market' | 'transparency' | 'my_rewards'>('market');

  const activeCertificates = certificates.filter(c => c.status === 'active');
  const retiredCertificates = certificates.filter(c => c.status === 'retired');

  const totalCarbonSequestrated = certificates.reduce((acc, c) => acc + c.tonsCO2e, 0);
  const totalRewardsDistributedUSD = payouts.reduce((acc, p) => acc + p.usdEquivalent, 0);

  const handleRetireSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCertForRetire) return;
    onRetireCertificate(selectedCertForRetire.certificateId, retireCompanyName);
    setSelectedCertForRetire(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-[#2D3B2D]">
      
      {/* Hero Stats Header */}
      <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-[#FAF3E0] border border-[#E6D0B3] flex items-center justify-center text-[#A67B5B]">
                <Coins className="w-5 h-5" />
              </div>
              <h1 className="text-xl font-black text-[#1A261A]">Transparent Reward & Carbon Credit Protocol</h1>
            </div>
            <p className="text-xs text-gray-500 font-medium mt-1">
              Direct peer-to-peer carbon credit issuance and transparent reward distribution engine
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div className="bg-[#F9FAF8] border border-[#E2E8DA] p-3.5 rounded-2xl">
              <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Total Carbon Drawdown</p>
              <p className="text-lg font-black text-[#4F6D4F] font-mono mt-0.5">{totalCarbonSequestrated} tCO2e</p>
            </div>

            <div className="bg-[#F9FAF8] border border-[#E2E8DA] p-3.5 rounded-2xl">
              <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Payouts Distributed</p>
              <p className="text-lg font-black text-[#A67B5B] font-mono mt-0.5">${totalRewardsDistributedUSD.toLocaleString()}</p>
            </div>

            <div className="bg-[#F9FAF8] border border-[#E2E8DA] p-3.5 rounded-2xl col-span-2 sm:col-span-1">
              <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Farmer Profit Share</p>
              <p className="text-lg font-black text-[#365336] font-mono mt-0.5">92% Direct</p>
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap items-center gap-2 border-t border-[#F0F4EC] mt-6 pt-4 text-xs">
          <button
            onClick={() => setActiveTab('market')}
            className={`px-4 py-2.5 rounded-2xl font-bold transition-all cursor-pointer ${
              activeTab === 'market'
                ? 'bg-[#4F6D4F] text-white shadow-sm'
                : 'text-[#2D3B2D] hover:bg-[#F0F4EC] bg-[#F9FAF8] border border-[#E2E8DA]'
            }`}
          >
            Carbon Credit Marketplace ({activeCertificates.length})
          </button>

          <button
            onClick={() => setActiveTab('transparency')}
            className={`px-4 py-2.5 rounded-2xl font-bold transition-all cursor-pointer ${
              activeTab === 'transparency'
                ? 'bg-[#4F6D4F] text-white shadow-sm'
                : 'text-[#2D3B2D] hover:bg-[#F0F4EC] bg-[#F9FAF8] border border-[#E2E8DA]'
            }`}
          >
            Reward Split & Protocol Transparency
          </button>

          <button
            onClick={() => setActiveTab('my_rewards')}
            className={`px-4 py-2.5 rounded-2xl font-bold transition-all cursor-pointer ${
              activeTab === 'my_rewards'
                ? 'bg-[#4F6D4F] text-white shadow-sm'
                : 'text-[#2D3B2D] hover:bg-[#F0F4EC] bg-[#F9FAF8] border border-[#E2E8DA]'
            }`}
          >
            On-Chain Payout Ledger ({payouts.length})
          </button>
        </div>
      </div>

      {/* Tab 1: Marketplace */}
      {activeTab === 'market' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-[#1A261A] flex items-center gap-2">
              <Award className="w-5 h-5 text-[#4F6D4F]" />
              <span>Certified Carbon Certificates Available</span>
            </h2>
            <span className="text-xs text-gray-500 font-medium">1 Credit = 1 Metric Ton CO2e Mitigated</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {activeCertificates.map(cert => (
              <div 
                key={cert.certificateId} 
                className="bg-white border border-[#E2E8DA] hover:border-[#D7E2CF] rounded-3xl p-6 shadow-sm transition-all"
              >
                <div className="flex items-center justify-between border-b border-[#F0F4EC] pb-3 mb-4">
                  <div>
                    <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-[#FAF3E0] text-[#A67B5B] border border-[#E6D0B3] font-bold">
                      {cert.espBadge}
                    </span>
                    <h3 className="text-base font-bold text-[#1A261A] mt-1.5">{cert.farmName}</h3>
                  </div>

                  <div className="text-right">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Volume</p>
                    <p className="text-lg font-black text-[#4F6D4F] font-mono">{cert.tonsCO2e} tCO2e</p>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-[#2D3B2D] mb-5 bg-[#F9FAF8] p-4 rounded-2xl border border-[#E2E8DA]">
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Farmer:</span>
                    <span className="font-bold text-[#1A261A]">{cert.farmerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Location:</span>
                    <span className="font-medium">{cert.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Issued Date:</span>
                    <span className="font-mono font-medium">{cert.issueDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Proof Hash:</span>
                    <span className="font-mono text-[#4F6D4F] font-bold text-[11px] truncate max-w-[160px]">{cert.certificateHash}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#F0F4EC]">
                  <div className="text-xs">
                    <span className="text-gray-500 font-medium">Market Price:</span>
                    <span className="font-mono font-bold text-[#1A261A] ml-1.5">${cert.tonsCO2e * 24} USD</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedCertForRetire(cert)}
                      className="bg-[#FAF3E0] hover:bg-[#F3E8C9] text-[#A67B5B] border border-[#E6D0B3] text-xs font-bold px-3.5 py-2 rounded-2xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Flame className="w-3.5 h-3.5 text-[#A67B5B]" />
                      <span>Retire (Offset)</span>
                    </button>

                    <button
                      onClick={() => onBuyCertificate(cert.certificateId, '0xCorpBuyerWallet88219')}
                      className="bg-[#4F6D4F] hover:bg-[#3E573E] text-white text-xs font-bold px-4 py-2 rounded-2xl shadow-sm flex items-center gap-1.5 cursor-pointer"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Buy Token</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Retired Certificates Log */}
          {retiredCertificates.length > 0 && (
            <div className="mt-8 pt-6 border-t border-[#E2E8DA]">
              <h3 className="text-sm font-bold text-[#1A261A] mb-3 flex items-center gap-2">
                <Flame className="w-4 h-4 text-[#A67B5B]" />
                <span>Permanently Retired Offset Certificates</span>
              </h3>
              <div className="space-y-2 text-xs">
                {retiredCertificates.map(r => (
                  <div key={r.certificateId} className="bg-white border border-[#E2E8DA] p-3.5 rounded-2xl flex items-center justify-between">
                    <div>
                      <p className="font-bold text-[#1A261A]">{r.certificateId} • Retired for <span className="text-[#A67B5B] font-bold">{r.retiredForCompany}</span></p>
                      <p className="text-[11px] text-gray-500 font-medium">{r.tonsCO2e} tCO2e • Farm: {r.farmName}</p>
                    </div>
                    <span className="font-mono text-[#4F6D4F] font-bold text-[11px]">Burn Tx Verified ✓</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Transparency & Split Breakdown */}
      {activeTab === 'transparency' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-[#1A261A] flex items-center gap-2">
              <PieChart className="w-5 h-5 text-[#4F6D4F]" />
              <span>Smart Contract Reward Split Architecture</span>
            </h2>
            <p className="text-xs text-gray-500 font-medium">
              Every carbon credit purchased on AgriBlock automatically executes an immutable smart contract distribution:
            </p>

            <div className="space-y-3 text-xs">
              <div className="bg-[#E9F0E4] border border-[#D7E2CF] p-4 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="font-bold text-[#2D3B2D] text-sm">92% Direct Farmer Payout</p>
                  <p className="text-[11px] text-gray-500 font-medium">Transferred instantly to farmer's cryptographic Web3 wallet address in $AGRI/USDT.</p>
                </div>
                <span className="font-mono font-black text-[#4F6D4F] text-lg">92%</span>
              </div>

              <div className="bg-[#F9FAF8] border border-[#E2E8DA] p-4 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="font-bold text-[#1A261A]">5% Ecosystem & Technology Pool</p>
                  <p className="text-[11px] text-gray-500 font-medium">Funds satellite telemetry models and open-source smart contract development.</p>
                </div>
                <span className="font-mono font-bold text-[#4F6D4F]">5%</span>
              </div>

              <div className="bg-[#F9FAF8] border border-[#E2E8DA] p-4 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="font-bold text-[#1A261A]">3% Independent Verification & ESP Auditing Fund</p>
                  <p className="text-[11px] text-gray-500 font-medium">Remunerates 3rd-party certified auditors for soil sampling and remote sensing audits.</p>
                </div>
                <span className="font-mono font-bold text-[#A67B5B]">3%</span>
              </div>
            </div>
          </div>

          <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-[#1A261A] flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#4F6D4F]" />
              <span>Trust & Reliability Mechanisms</span>
            </h2>
            <p className="text-xs text-gray-500 font-medium">
              How AgriBlock guarantees double-counting prevention and verifiable trust:
            </p>

            <ul className="space-y-3 text-xs text-[#2D3B2D]">
              <li className="flex items-start space-x-3 bg-[#F9FAF8] p-3.5 rounded-2xl border border-[#E2E8DA]">
                <CheckCircle2 className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                <span className="font-medium"><strong className="font-bold text-[#1A261A]">Merkle Proof Signatures:</strong> Every carbon certificate contains a cryptographic SHA-256 Merkle root tied to its block height.</span>
              </li>
              <li className="flex items-start space-x-3 bg-[#F9FAF8] p-3.5 rounded-2xl border border-[#E2E8DA]">
                <CheckCircle2 className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                <span className="font-medium"><strong className="font-bold text-[#1A261A]">No Middleman Extraction:</strong> Traditional carbon broker fees (often 40-60%) are completely eliminated.</span>
              </li>
              <li className="flex items-start space-x-3 bg-[#F9FAF8] p-3.5 rounded-2xl border border-[#E2E8DA]">
                <CheckCircle2 className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                <span className="font-medium"><strong className="font-bold text-[#1A261A]">Auditor Multi-Sig:</strong> Certificates cannot be issued without 2-of-3 consortium signatures (AI Telemetry + Independent Auditor + ESP Authority).</span>
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab 3: Payout Log */}
      {activeTab === 'my_rewards' && (
        <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm">
          <h2 className="text-base font-bold text-[#1A261A] mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#4F6D4F]" />
            <span>On-Chain Reward Payout History</span>
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F0F4EC] text-[#4F6D4F] font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3.5 rounded-l-2xl">Farmer</th>
                  <th className="p-3.5">Carbon Volume</th>
                  <th className="p-3.5">Base Reward</th>
                  <th className="p-3.5">ESP Tier Bonus</th>
                  <th className="p-3.5">Total $AGRI</th>
                  <th className="p-3.5">Transaction Hash</th>
                  <th className="p-3.5 rounded-r-2xl">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F0F4EC]">
                {payouts.map(p => (
                  <tr key={p.id} className="hover:bg-[#F9FAF8]">
                    <td className="p-3.5 font-bold text-[#1A261A]">{p.farmerName}</td>
                    <td className="p-3.5 font-mono text-[#4F6D4F] font-bold">{p.carbonTons} tCO2e</td>
                    <td className="p-3.5 font-mono text-gray-600">{p.baseRewardTokens.toLocaleString()}</td>
                    <td className="p-3.5 font-mono text-[#A67B5B] font-bold">+{p.espBonusTokens.toLocaleString()}</td>
                    <td className="p-3.5 font-mono text-[#4F6D4F] font-black">{p.totalTokens.toLocaleString()} $AGRI</td>
                    <td className="p-3.5 font-mono text-gray-500 text-[11px] truncate max-w-[140px]">{p.txHash}</td>
                    <td className="p-3.5">
                      <span className="bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF] text-[10px] px-2.5 py-0.5 rounded-full font-bold">
                        Mined ✓
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal for Retiring Certificate */}
      {selectedCertForRetire && (
        <div className="fixed inset-0 bg-[#1A261A]/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E2E8DA] rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-[#1A261A] mb-2 flex items-center gap-2">
              <Flame className="w-5 h-5 text-[#A67B5B]" />
              <span>Permanently Retire Carbon Certificate</span>
            </h3>
            <p className="text-xs text-gray-500 font-medium mb-4">
              Retiring burns {selectedCertForRetire.tonsCO2e} tCO2e carbon credits on-chain to generate an official Net-Zero ESG compliance certificate.
            </p>

            <form onSubmit={handleRetireSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1">Retiring Corporation Name</label>
                <input
                  type="text"
                  value={retireCompanyName}
                  onChange={e => setRetireCompanyName(e.target.value)}
                  required
                  className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-3.5 py-2.5 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                />
              </div>

              <div className="bg-[#FAF3E0] border border-[#E6D0B3] p-3.5 rounded-2xl text-xs text-[#A67B5B] font-medium">
                This transaction is irreversible and will mark Certificate ID <span className="font-mono font-bold">{selectedCertForRetire.certificateId}</span> as retired.
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedCertForRetire(null)}
                  className="px-4 py-2.5 rounded-2xl text-xs font-bold text-gray-600 bg-[#F0F4EC] hover:bg-[#E2E8DA] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#A67B5B] hover:bg-[#8F6749] text-white font-bold text-xs px-5 py-2.5 rounded-2xl shadow-sm cursor-pointer"
                >
                  Confirm Retirement & Burn Token
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
