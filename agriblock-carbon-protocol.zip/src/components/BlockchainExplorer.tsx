import React, { useState } from 'react';
import { BlockchainBlock, CarbonCertificate } from '../types';
import { verifyCertificateAuthenticity } from '../lib/blockchain';
import { 
  Database, 
  Search, 
  ShieldCheck, 
  Cpu, 
  Box, 
  CheckCircle2, 
  XCircle, 
  Code2, 
  QrCode, 
  Hash, 
  Layers, 
  Sparkles,
  ExternalLink,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface BlockchainExplorerProps {
  blocks: BlockchainBlock[];
  certificates: CarbonCertificate[];
}

export const BlockchainExplorer: React.FC<BlockchainExplorerProps> = ({
  blocks,
  certificates
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'blocks' | 'contracts' | 'authenticator'>('blocks');
  
  // Verification lookup state
  const [verifyCertHash, setVerifyCertHash] = useState(certificates[0]?.certificateHash || '');
  const [verificationResult, setVerificationResult] = useState<{
    isValid: boolean;
    details: string;
    certFound?: CarbonCertificate;
  } | null>(null);

  const [expandedBlockIndex, setExpandedBlockIndex] = useState<number | null>(blocks[0]?.index || null);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    const certFound = certificates.find(c => 
      c.certificateHash.toLowerCase() === verifyCertHash.trim().toLowerCase() ||
      c.certificateId.toLowerCase() === verifyCertHash.trim().toLowerCase()
    );

    if (certFound) {
      const res = await verifyCertificateAuthenticity(certFound, blocks);
      setVerificationResult({
        ...res,
        certFound
      });
    } else {
      setVerificationResult({
        isValid: false,
        details: 'Certificate hash or ID not found in current AgriBlock Ledger.'
      });
    }
  };

  const filteredBlocks = blocks.filter(b => 
    b.hash.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.index.toString().includes(searchQuery) ||
    b.transactions.some(tx => tx.txHash.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-[#2D3B2D]">
      
      {/* Header */}
      <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-[#E9F0E4] border border-[#D7E2CF] flex items-center justify-center text-[#4F6D4F]">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-black text-[#1A261A]">AgriBlock Ledger & Certificate Explorer</h1>
                <span className="text-[10px] px-2.5 py-0.5 bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF] rounded-full font-mono font-bold">
                  Mainnet Live
                </span>
              </div>
              <p className="text-xs text-gray-500 font-medium mt-0.5">
                Consortium Proof-of-Authority nodes validating ESP carbon credits with SHA-256 Merkle proofs
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono">
            <div className="bg-[#F0F4EC] px-3.5 py-2 rounded-2xl border border-[#D7E2CF]">
              <span className="text-gray-500">Block Height: </span>
              <span className="font-bold text-[#4F6D4F]">#{blocks[blocks.length - 1]?.index || 1088}</span>
            </div>
            <div className="bg-[#F0F4EC] px-3.5 py-2 rounded-2xl border border-[#D7E2CF]">
              <span className="text-gray-500">Consortium Nodes: </span>
              <span className="font-bold text-[#365336]">3 Active</span>
            </div>
          </div>
        </div>

        {/* Tab Selection & Search Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-[#F0F4EC] mt-6 pt-4 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('blocks')}
              className={`px-4 py-2.5 rounded-2xl font-bold transition-all cursor-pointer ${
                activeTab === 'blocks'
                  ? 'bg-[#4F6D4F] text-white shadow-sm'
                  : 'text-[#2D3B2D] hover:bg-[#F0F4EC] bg-[#F9FAF8] border border-[#E2E8DA]'
              }`}
            >
              Blocks & Transactions
            </button>

            <button
              onClick={() => setActiveTab('authenticator')}
              className={`px-4 py-2.5 rounded-2xl font-bold transition-all cursor-pointer ${
                activeTab === 'authenticator'
                  ? 'bg-[#4F6D4F] text-white shadow-sm'
                  : 'text-[#2D3B2D] hover:bg-[#F0F4EC] bg-[#F9FAF8] border border-[#E2E8DA]'
              }`}
            >
              Public Certificate Authenticator
            </button>

            <button
              onClick={() => setActiveTab('contracts')}
              className={`px-4 py-2.5 rounded-2xl font-bold transition-all cursor-pointer ${
                activeTab === 'contracts'
                  ? 'bg-[#4F6D4F] text-white shadow-sm'
                  : 'text-[#2D3B2D] hover:bg-[#F0F4EC] bg-[#F9FAF8] border border-[#E2E8DA]'
              }`}
            >
              Smart Contract Inspector
            </button>
          </div>

          {activeTab === 'blocks' && (
            <div className="relative max-w-xs w-full">
              <Search className="w-3.5 h-3.5 absolute left-3.5 top-3 text-gray-400" />
              <input
                type="text"
                placeholder="Search Block, Hash, or Tx..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl pl-9 pr-3.5 py-2 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
              />
            </div>
          )}
        </div>
      </div>

      {/* Tab 1: Blocks & Transactions */}
      {activeTab === 'blocks' && (
        <div className="space-y-4">
          {filteredBlocks.map(block => {
            const isExpanded = expandedBlockIndex === block.index;

            return (
              <div key={block.index} className="bg-white border border-[#E2E8DA] rounded-3xl overflow-hidden shadow-sm">
                <div
                  onClick={() => setExpandedBlockIndex(isExpanded ? null : block.index)}
                  className="p-5 bg-white hover:bg-[#F9FAF8] cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <div className="p-3 rounded-2xl bg-[#E9F0E4] border border-[#D7E2CF] text-[#4F6D4F]">
                      <Box className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-[#1A261A] text-sm">Block #{block.index}</span>
                        <span className="text-[10px] text-gray-500 font-mono font-medium">
                          {block.transactions.length} Transactions
                        </span>
                      </div>
                      <p className="text-[11px] font-mono text-gray-500 truncate max-w-xs sm:max-w-md font-medium">
                        Hash: <span className="text-[#4F6D4F] font-bold">{block.hash}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4 text-xs font-mono">
                    <div className="text-right">
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Validator Node</p>
                      <p className="text-[#2D3B2D] font-sans font-bold">{block.validatorNode}</p>
                    </div>
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="p-5 bg-[#F9FAF8] border-t border-[#E2E8DA] space-y-4 text-xs">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[#2D3B2D] font-mono text-[11px] bg-white p-4 rounded-2xl border border-[#E2E8DA]">
                      <div>
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Previous Hash:</span>
                        <p className="text-[#2D3B2D] truncate font-medium">{block.previousHash}</p>
                      </div>
                      <div>
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Merkle Root:</span>
                        <p className="text-[#4F6D4F] font-bold truncate">{block.merkleRoot}</p>
                      </div>
                      <div>
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Timestamp:</span>
                        <p className="text-[#2D3B2D] font-medium">{block.timestamp}</p>
                      </div>
                      <div>
                        <span className="text-gray-400 font-bold uppercase tracking-wider text-[10px]">Nonce:</span>
                        <p className="text-[#2D3B2D] font-medium">{block.nonce}</p>
                      </div>
                    </div>

                    <div>
                      <p className="font-bold text-[#4F6D4F] uppercase tracking-wider text-[10px] mb-2">Block Transactions Log</p>
                      <div className="space-y-2">
                        {block.transactions.map(tx => (
                          <div key={tx.txHash} className="p-3.5 rounded-2xl bg-white border border-[#E2E8DA] space-y-1">
                            <div className="flex items-center justify-between font-mono">
                              <span className="font-bold text-[#4F6D4F]">{tx.type}</span>
                              <span className="text-gray-400 text-[10px]">{tx.timestamp}</span>
                            </div>
                            <p className="font-mono text-[11px] text-gray-500 truncate font-medium">
                              TxHash: <span className="text-[#1A261A] font-bold">{tx.txHash}</span>
                            </p>
                            <div className="text-[11px] text-gray-600 pt-1 font-mono">
                              Payload: {JSON.stringify(tx.payload)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: Public Certificate Authenticator */}
      {activeTab === 'authenticator' && (
        <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-[#E9F0E4] border border-[#D7E2CF] flex items-center justify-center text-[#4F6D4F]">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1A261A]">Cryptographic Certificate Verification</h2>
              <p className="text-xs text-gray-500 font-medium">Enter a Carbon Certificate SHA-256 Hash or Certificate ID to verify on-chain validity</p>
            </div>
          </div>

          <form onSubmit={handleVerify} className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              placeholder="e.g. 0x3a2e91b8a21f7c89d023b18... or CERT-2026-AGRI-8832"
              value={verifyCertHash}
              onChange={e => setVerifyCertHash(e.target.value)}
              required
              className="flex-grow bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-4 py-3 text-xs text-[#2D3B2D] font-mono focus:outline-none focus:border-[#4F6D4F]"
            />
            <button
              type="submit"
              className="bg-[#4F6D4F] hover:bg-[#3E573E] text-white font-bold text-xs px-6 py-3 rounded-2xl shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span>Verify On-Chain</span>
            </button>
          </form>

          {/* Verification Outcome */}
          {verificationResult && (
            <div className={`p-5 rounded-2xl border text-xs space-y-3 ${
              verificationResult.isValid
                ? 'bg-[#E9F0E4] border-[#D7E2CF] text-[#2D3B2D]'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}>
              <div className="flex items-center space-x-2">
                {verificationResult.isValid ? (
                  <CheckCircle2 className="w-5 h-5 text-[#4F6D4F]" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-500" />
                )}
                <span className="font-bold text-sm">
                  {verificationResult.isValid ? 'Authentic On-Chain Carbon Certificate' : 'Verification Failed'}
                </span>
              </div>

              <p className="text-gray-600 font-medium leading-relaxed">{verificationResult.details}</p>

              {verificationResult.certFound && (
                <div className="bg-white p-4 rounded-2xl border border-[#E2E8DA] space-y-2 font-mono text-[11px] text-[#2D3B2D]">
                  <div className="flex justify-between">
                    <span className="text-gray-400 font-medium">Certificate ID:</span>
                    <span className="font-bold text-[#1A261A]">{verificationResult.certFound.certificateId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 font-medium">Farmer & Location:</span>
                    <span className="text-[#2D3B2D] font-medium">{verificationResult.certFound.farmerName} ({verificationResult.certFound.location})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 font-medium">Volume Mitigated:</span>
                    <span className="font-bold text-[#4F6D4F]">{verificationResult.certFound.tonsCO2e} tCO2e</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 font-medium">ESP Standard Badge:</span>
                    <span className="text-[#A67B5B] font-bold">{verificationResult.certFound.espBadge}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 font-medium">Block Number:</span>
                    <span className="text-[#4F6D4F] font-bold">#{verificationResult.certFound.blockNumber}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Smart Contract Inspector */}
      {activeTab === 'contracts' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center space-x-2">
              <Code2 className="w-5 h-5 text-[#4F6D4F]" />
              <h3 className="text-sm font-bold text-[#1A261A]">CarbonMintingContract.sol</h3>
            </div>
            <p className="text-xs text-gray-500 font-medium">Enforces ESP score thresholds prior to minting carbon credit tokens.</p>
            
            <div className="bg-[#F9FAF8] p-4 rounded-2xl border border-[#E2E8DA] font-mono text-[11px] text-[#2D3B2D] overflow-x-auto">
              <pre>{`// SPDX-License-Identifier: MIT
contract CarbonMintingContract {
    uint256 public constant MIN_ESP_SCORE = 70;
    
    function mintCertificate(
        address farmer,
        uint256 tonsCO2e,
        uint256 espScore,
        bytes memory auditorSig
    ) external returns (bytes32 certHash) {
        require(espScore >= MIN_ESP_SCORE, "ESP Criteria Unmet");
        require(verifySignature(auditorSig), "Invalid Auditor");
        
        certHash = keccak256(abi.encodePacked(farmer, tonsCO2e, block.timestamp));
        _mint(farmer, certHash, tonsCO2e);
    }
}`}</pre>
            </div>
          </div>

          <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center space-x-2">
              <Code2 className="w-5 h-5 text-[#A67B5B]" />
              <h3 className="text-sm font-bold text-[#1A261A]">ESPComplianceManager.sol</h3>
            </div>
            <p className="text-xs text-gray-500 font-medium">Aggregates soil organic carbon, water runoff, and social labor indices.</p>

            <div className="bg-[#F9FAF8] p-4 rounded-2xl border border-[#E2E8DA] font-mono text-[11px] text-[#2D3B2D] overflow-x-auto">
              <pre>{`// SPDX-License-Identifier: MIT
contract ESPComplianceManager {
    struct ESPMetric {
        uint8 soilScore;
        uint8 waterScore;
        uint8 socialEquityScore;
        bool verifiedByConsortium;
    }
    
    function calculateTier(uint8 totalScore) public pure returns (string memory) {
        if (totalScore >= 90) return "Gold Standard";
        if (totalScore >= 80) return "Silver Standard";
        return "Bronze Standard";
    }
}`}</pre>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
