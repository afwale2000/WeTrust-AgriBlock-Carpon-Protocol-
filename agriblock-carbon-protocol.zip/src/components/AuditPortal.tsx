import React, { useState } from 'react';
import { FarmingProject, AuditRecord } from '../types';
import { evaluateIssuanceCriteria } from '../lib/blockchain';
import { 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  FileCheck, 
  Sparkles, 
  Award, 
  Lock, 
  AlertTriangle, 
  Clock, 
  ExternalLink,
  ChevronRight,
  Eye,
  Building2,
  BadgeCheck
} from 'lucide-react';

interface AuditPortalProps {
  projects: FarmingProject[];
  onApproveAndMint: (projectId: string, auditRecord: AuditRecord) => void;
  onSelectProjectForView: (project: FarmingProject) => void;
}

export const AuditPortal: React.FC<AuditPortalProps> = ({
  projects,
  onApproveAndMint,
  onSelectProjectForView
}) => {
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(
    projects.find(p => p.status === 'ai_verified' || p.status === 'pending_audit')?.id || projects[0]?.id || null
  );

  const [auditorName, setAuditorName] = useState('Dr. Marcus Vance');
  const [auditorOrg, setAuditorOrg] = useState('Global Carbon Audit Consortium (GCAC)');
  const [auditorNotes, setAuditorNotes] = useState('Satellite radar backscatter and soil core sampling match ESP Gold standard expectations.');

  // Criteria toggle checks
  const [baselineValidated, setBaselineValidated] = useState(true);
  const [espComplianceVerified, setEspComplianceVerified] = useState(true);
  const [satelliteImageryMatched, setSatelliteImageryMatched] = useState(true);
  const [noDoubleCounting, setNoDoubleCounting] = useState(true);
  const [additionalityProven, setAdditionalityProven] = useState(true);

  const activeProject = projects.find(p => p.id === selectedProjectId);

  // Evaluate Issuance Criteria according to ESP demand
  const criteriaEvaluation = activeProject?.assessmentResult ? evaluateIssuanceCriteria(
    activeProject.assessmentResult.espCompliance.totalESPScore,
    activeProject.assessmentResult.aiConfidenceScore,
    baselineValidated && espComplianceVerified && satelliteImageryMatched && noDoubleCounting && additionalityProven,
    additionalityProven
  ) : { eligible: false, reasons: ['Missing assessment data'], espBadge: 'Bronze ESP' as const };

  const handleApprove = () => {
    if (!activeProject) return;

    const auditRecord: AuditRecord = {
      id: `AUD-${Math.floor(1000 + Math.random() * 9000)}`,
      projectId: activeProject.id,
      auditorName,
      auditorOrg,
      auditorWallet: '0x88f2190A98032d15A019bC398188C02B90c3A08',
      auditTimestamp: new Date().toISOString(),
      status: 'approved',
      criteriaChecks: {
        baselineValidated,
        espComplianceVerified,
        satelliteImageryMatched,
        noDoubleCounting,
        additionalityProven
      },
      auditorNotes,
      signatureHash: `0x${Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('')}`
    };

    onApproveAndMint(activeProject.id, auditRecord);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-[#2D3B2D]">
      
      {/* Header Banner */}
      <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-[#E9F0E4] border border-[#D7E2CF] flex items-center justify-center text-[#4F6D4F]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-black text-[#1A261A]">Carbon Certification & Auditing Hub</h1>
              <p className="text-xs text-gray-500 font-medium">
                Independent 3rd-party validation desk enforcing ESP (Environmental & Social Performance) criteria
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3 text-xs bg-[#F0F4EC] px-4 py-2.5 rounded-2xl border border-[#D7E2CF]">
            <Building2 className="w-4 h-4 text-[#4F6D4F]" />
            <div>
              <p className="font-bold text-[#2D3B2D]">{auditorOrg}</p>
              <p className="text-[10px] text-gray-500 font-medium">Auditor: {auditorName}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Col: Projects Selector List */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-[#769C76] uppercase tracking-wider mb-2">
            Assessment Submissions ({projects.length})
          </h2>

          {projects.map(p => {
            const isSelected = p.id === selectedProjectId;
            const isCertified = p.status === 'certified';

            return (
              <div
                key={p.id}
                onClick={() => setSelectedProjectId(p.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                  isSelected 
                    ? 'bg-[#E9F0E4] border-[#4F6D4F] shadow-sm' 
                    : 'bg-white border-[#E2E8DA] hover:border-[#D7E2CF]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-sm text-[#1A261A]">{p.farmName}</span>
                  {isCertified ? (
                    <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF] font-bold">
                      Certified ✓
                    </span>
                  ) : (
                    <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-[#FAF3E0] text-[#A67B5B] border border-[#E6D0B3] font-bold">
                      Needs Audit
                    </span>
                  )}
                </div>

                <p className="text-xs text-gray-500 font-medium">
                  Farmer: {p.farmerName} • {p.areaHectares} Ha
                </p>

                {p.assessmentResult && (
                  <div className="flex items-center justify-between mt-3 text-xs pt-2 border-t border-[#E2E8DA]">
                    <span className="text-gray-500 font-medium">Carbon Yield:</span>
                    <span className="font-mono font-bold text-[#4F6D4F]">{p.assessmentResult.netCarbonCreditsYield} tCO2e</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Right Col (2 cols): Selected Project Audit Workspace */}
        <div className="lg:col-span-2">
          {activeProject ? (
            <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm space-y-6">
              
              {/* Project Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F0F4EC] pb-4">
                <div>
                  <h3 className="text-lg font-bold text-[#1A261A]">{activeProject.farmName}</h3>
                  <p className="text-xs text-gray-500 font-medium">
                    Location: {activeProject.location} • Practices: <span className="text-[#4F6D4F] font-bold">{activeProject.primaryPractice.replace('_', ' ')}</span>
                  </p>
                </div>

                <button
                  onClick={() => onSelectProjectForView(activeProject)}
                  className="flex items-center space-x-1.5 text-xs text-[#4F6D4F] hover:text-[#3E573E] bg-[#F0F4EC] border border-[#D7E2CF] px-3.5 py-2 rounded-2xl font-bold"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Inspect AI Telemetry Data</span>
                </button>
              </div>

              {/* Criteria Checkbox Panel for Certification Criteria */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#4F6D4F] flex items-center gap-2">
                    <FileCheck className="w-4 h-4 text-[#4F6D4F]" />
                    <span>ESP Certification Criteria Verification</span>
                  </h4>
                  <span className="text-[11px] text-gray-400 font-mono">Verra VM0042 & ESP Guideline Compliant</span>
                </div>

                <div className="space-y-2.5 text-xs">
                  <label className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F9FAF8] border border-[#E2E8DA] cursor-pointer hover:border-[#D7E2CF]">
                    <div className="flex items-center space-x-3">
                      <input 
                        type="checkbox"
                        checked={baselineValidated}
                        onChange={e => setBaselineValidated(e.target.checked)}
                        className="w-4 h-4 accent-[#4F6D4F] rounded"
                      />
                      <div>
                        <p className="font-bold text-[#1A261A]">1. Historical Baseline Emissions Validated</p>
                        <p className="text-[11px] text-gray-500 font-medium">Verified historical tillage and synthetic fertilizer baseline records.</p>
                      </div>
                    </div>
                    {baselineValidated ? <CheckCircle2 className="w-4 h-4 text-[#4F6D4F]" /> : <XCircle className="w-4 h-4 text-rose-500" />}
                  </label>

                  <label className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F9FAF8] border border-[#E2E8DA] cursor-pointer hover:border-[#D7E2CF]">
                    <div className="flex items-center space-x-3">
                      <input 
                        type="checkbox"
                        checked={espComplianceVerified}
                        onChange={e => setEspComplianceVerified(e.target.checked)}
                        className="w-4 h-4 accent-[#4F6D4F] rounded"
                      />
                      <div>
                        <p className="font-bold text-[#1A261A]">2. ESP Environmental & Social Standard (Score &gt;= 75%)</p>
                        <p className="text-[11px] text-gray-500 font-medium">Soil organic carbon, water runoff, and fair social labor conditions verified.</p>
                      </div>
                    </div>
                    {espComplianceVerified ? <CheckCircle2 className="w-4 h-4 text-[#4F6D4F]" /> : <XCircle className="w-4 h-4 text-rose-500" />}
                  </label>

                  <label className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F9FAF8] border border-[#E2E8DA] cursor-pointer hover:border-[#D7E2CF]">
                    <div className="flex items-center space-x-3">
                      <input 
                        type="checkbox"
                        checked={satelliteImageryMatched}
                        onChange={e => setSatelliteImageryMatched(e.target.checked)}
                        className="w-4 h-4 accent-[#4F6D4F] rounded"
                      />
                      <div>
                        <p className="font-bold text-[#1A261A]">3. Landsat/Sentinel Satellite Radar Biomass Match</p>
                        <p className="text-[11px] text-gray-500 font-medium">NDVI index and cover crop ground canopy confirm active sequestration.</p>
                      </div>
                    </div>
                    {satelliteImageryMatched ? <CheckCircle2 className="w-4 h-4 text-[#4F6D4F]" /> : <XCircle className="w-4 h-4 text-rose-500" />}
                  </label>

                  <label className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F9FAF8] border border-[#E2E8DA] cursor-pointer hover:border-[#D7E2CF]">
                    <div className="flex items-center space-x-3">
                      <input 
                        type="checkbox"
                        checked={additionalityProven}
                        onChange={e => setAdditionalityProven(e.target.checked)}
                        className="w-4 h-4 accent-[#4F6D4F] rounded"
                      />
                      <div>
                        <p className="font-bold text-[#1A261A]">4. Additionality Proven (Beyond Regulatory Baselines)</p>
                        <p className="text-[11px] text-gray-500 font-medium">Carbon drawdown would not occur without carbon credit financial incentives.</p>
                      </div>
                    </div>
                    {additionalityProven ? <CheckCircle2 className="w-4 h-4 text-[#4F6D4F]" /> : <XCircle className="w-4 h-4 text-rose-500" />}
                  </label>

                  <label className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F9FAF8] border border-[#E2E8DA] cursor-pointer hover:border-[#D7E2CF]">
                    <div className="flex items-center space-x-3">
                      <input 
                        type="checkbox"
                        checked={noDoubleCounting}
                        onChange={e => setNoDoubleCounting(e.target.checked)}
                        className="w-4 h-4 accent-[#4F6D4F] rounded"
                      />
                      <div>
                        <p className="font-bold text-[#1A261A]">5. No Double Counting (Global Registry Query)</p>
                        <p className="text-[11px] text-gray-500 font-medium">Coordinates verified clear on international carbon credit registries.</p>
                      </div>
                    </div>
                    {noDoubleCounting ? <CheckCircle2 className="w-4 h-4 text-[#4F6D4F]" /> : <XCircle className="w-4 h-4 text-rose-500" />}
                  </label>
                </div>
              </div>

              {/* Eligibility Check Outcome Box */}
              <div className={`p-4 rounded-2xl border text-xs ${
                criteriaEvaluation.eligible
                  ? 'bg-[#E9F0E4] border-[#D7E2CF] text-[#2D3B2D]'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm flex items-center gap-2">
                    {criteriaEvaluation.eligible ? (
                      <>
                        <BadgeCheck className="w-5 h-5 text-[#4F6D4F]" />
                        <span>Eligible for On-Chain Certificate Minting ({criteriaEvaluation.espBadge})</span>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-5 h-5 text-rose-500" />
                        <span>Issuance Criteria Not Yet Met</span>
                      </>
                    )}
                  </span>
                </div>

                {!criteriaEvaluation.eligible && (
                  <ul className="list-disc list-inside mt-2 space-y-1 text-[11px] text-rose-700 font-medium">
                    {criteriaEvaluation.reasons.map((r, i) => <li key={i}>{r}</li>)}
                  </ul>
                )}
              </div>

              {/* Auditor Sign-off Input */}
              <div className="space-y-3 pt-2">
                <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider">Auditor Notes & Digital Sign-off</label>
                <textarea
                  rows={2}
                  value={auditorNotes}
                  onChange={e => setAuditorNotes(e.target.value)}
                  className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl p-3 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                />
              </div>

              {/* Mint Certificate Action */}
              <div className="flex items-center justify-between pt-4 border-t border-[#F0F4EC]">
                <div className="text-xs text-gray-500 font-medium">
                  <p>Certificate will be minted as cryptographic Merkle Proof block.</p>
                </div>

                <button
                  disabled={!criteriaEvaluation.eligible || activeProject.status === 'certified'}
                  onClick={handleApprove}
                  className="bg-[#4F6D4F] hover:bg-[#3E573E] text-white font-bold text-xs px-6 py-3 rounded-2xl shadow-sm flex items-center gap-2 disabled:opacity-40 cursor-pointer"
                >
                  <Award className="w-4 h-4" />
                  <span>
                    {activeProject.status === 'certified' ? 'Certificate Already Minted' : 'Sign Audit & Mint Carbon Certificate'}
                  </span>
                </button>
              </div>

            </div>
          ) : (
            <div className="bg-white border border-[#E2E8DA] rounded-3xl p-12 text-center text-gray-500 text-xs">
              Select a project from the left to begin audit verification.
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
