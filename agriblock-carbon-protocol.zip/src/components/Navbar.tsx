import React, { useState } from 'react';
import { UserRole, FarmerProfile } from '../types';
import { 
  Sprout, 
  ShieldCheck, 
  Coins, 
  Database, 
  Wallet, 
  CheckCircle2, 
  ExternalLink,
  UserCheck,
  ChevronDown,
  Sparkles,
  Search
} from 'lucide-react';

interface NavbarProps {
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  activeFarmer: FarmerProfile;
  onSelectFarmer: (farmer: FarmerProfile) => void;
  farmers: FarmerProfile[];
  blockCount: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onSelectRole,
  activeFarmer,
  onSelectFarmer,
  farmers,
  blockCount,
  activeTab,
  setActiveTab
}) => {
  const [isWalletConnected, setIsWalletConnected] = useState(true);
  const [showRoleMenu, setShowRoleMenu] = useState(false);

  return (
    <header className="bg-white border-b border-[#E2E8DA] sticky top-0 z-50 text-[#2D3B2D] shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Protocol Title */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('farmer')}>
            <div className="w-10 h-10 rounded-xl bg-[#4F6D4F] flex items-center justify-center text-white shadow-sm">
              <Sprout className="w-6 h-6 text-white font-bold" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-xl tracking-tight text-[#1A261A]">
                  TerraTrust <span className="text-[#769C76] font-medium">Chain</span>
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#E9F0E4] text-[#4F6D4F] font-mono font-bold border border-[#D7E2CF]">
                  ESP-2.4
                </span>
              </div>
              <p className="text-[11px] text-gray-500 -mt-0.5 font-medium">Blockchain Carbon Farming Ledger</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1">
            <button
              onClick={() => { setActiveTab('farmer'); onSelectRole('farmer'); }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'farmer' 
                  ? 'bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF]' 
                  : 'text-gray-500 hover:text-[#4F6D4F] hover:bg-[#F0F4EC]'
              }`}
            >
              <Sprout className="w-4 h-4" />
              <span>Farmer Portal</span>
            </button>

            <button
              onClick={() => { setActiveTab('audit'); onSelectRole('auditor'); }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'audit' 
                  ? 'bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF]' 
                  : 'text-gray-500 hover:text-[#4F6D4F] hover:bg-[#F0F4EC]'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Auditing & ESP</span>
            </button>

            <button
              onClick={() => { setActiveTab('rewards'); onSelectRole('buyer'); }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'rewards' 
                  ? 'bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF]' 
                  : 'text-gray-500 hover:text-[#4F6D4F] hover:bg-[#F0F4EC]'
              }`}
            >
              <Coins className="w-4 h-4" />
              <span>Rewards & Market</span>
            </button>

            <button
              onClick={() => { setActiveTab('explorer'); onSelectRole('public'); }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'explorer' 
                  ? 'bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF]' 
                  : 'text-gray-500 hover:text-[#4F6D4F] hover:bg-[#F0F4EC]'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Block Explorer</span>
            </button>
          </nav>

          {/* Right Actions: Role Switcher & Wallet */}
          <div className="flex items-center space-x-3">
            
            {/* Farmer Login Selector */}
            {activeTab === 'farmer' && (
              <div className="relative">
                <button
                  onClick={() => setShowRoleMenu(!showRoleMenu)}
                  className="flex items-center space-x-2 text-xs bg-[#F0F4EC] hover:bg-[#E2E8DA] border border-[#D7E2CF] text-[#2D3B2D] px-3.5 py-2 rounded-full transition-colors font-semibold"
                >
                  <UserCheck className="w-3.5 h-3.5 text-[#4F6D4F]" />
                  <span className="font-semibold max-w-[120px] truncate">{activeFarmer.name}</span>
                  <ChevronDown className="w-3 h-3 text-gray-400" />
                </button>

                {showRoleMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-white border border-[#E2E8DA] rounded-2xl shadow-lg z-50 p-2">
                    <p className="text-[10px] font-bold text-[#769C76] px-3 py-1.5 uppercase tracking-wider">
                      Switch Farmer Account
                    </p>
                    {farmers.map(f => (
                      <button
                        key={f.id}
                        onClick={() => {
                          onSelectFarmer(f);
                          setShowRoleMenu(false);
                        }}
                        className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                          f.id === activeFarmer.id ? 'bg-[#E9F0E4] text-[#4F6D4F] font-bold' : 'text-[#2D3B2D] hover:bg-[#F0F4EC]'
                        }`}
                      >
                        <div>
                          <p className="font-semibold">{f.name}</p>
                          <p className="text-[10px] text-gray-500">{f.farmName}</p>
                        </div>
                        {f.id === activeFarmer.id && <CheckCircle2 className="w-3.5 h-3.5 text-[#4F6D4F]" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Web3 Wallet Connection Badge */}
            <div className="flex items-center space-x-2 bg-[#E9F0E4] border border-[#D7E2CF] rounded-full px-4 py-2">
              <div className="flex items-center space-x-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600"></span>
                </span>
                <span className="text-xs font-mono font-bold text-[#2D3B2D] hidden sm:inline">
                  {activeFarmer.walletAddress.slice(0, 5)}...{activeFarmer.walletAddress.slice(-4)}
                </span>
              </div>
              <div className="h-3 w-[1px] bg-[#D7E2CF] mx-1"></div>
              <div className="flex items-center space-x-1 text-xs text-[#A67B5B] font-bold">
                <Coins className="w-3.5 h-3.5" />
                <span>{activeFarmer.rewardTokensBalance.toLocaleString()} $AGRI</span>
              </div>
            </div>

          </div>
        </div>
      </div>
      
      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-[#E2E8DA] py-2 bg-white text-xs">
        <button 
          onClick={() => { setActiveTab('farmer'); onSelectRole('farmer'); }}
          className={`flex flex-col items-center p-1 font-semibold ${activeTab === 'farmer' ? 'text-[#4F6D4F]' : 'text-gray-400'}`}
        >
          <Sprout className="w-4 h-4" />
          <span>Farmer</span>
        </button>
        <button 
          onClick={() => { setActiveTab('audit'); onSelectRole('auditor'); }}
          className={`flex flex-col items-center p-1 font-semibold ${activeTab === 'audit' ? 'text-[#4F6D4F]' : 'text-gray-400'}`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Auditing</span>
        </button>
        <button 
          onClick={() => { setActiveTab('rewards'); onSelectRole('buyer'); }}
          className={`flex flex-col items-center p-1 font-semibold ${activeTab === 'rewards' ? 'text-[#4F6D4F]' : 'text-gray-400'}`}
        >
          <Coins className="w-4 h-4" />
          <span>Rewards</span>
        </button>
        <button 
          onClick={() => { setActiveTab('explorer'); onSelectRole('public'); }}
          className={`flex flex-col items-center p-1 font-semibold ${activeTab === 'explorer' ? 'text-[#4F6D4F]' : 'text-gray-400'}`}
        >
          <Database className="w-4 h-4" />
          <span>Ledger</span>
        </button>
      </div>
    </header>
  );
};
