import React from 'react';
import { FarmingProject } from '../types';
import { 
  Sprout, 
  ShieldCheck, 
  Sparkles, 
  ArrowLeft, 
  CheckCircle2, 
  AlertTriangle, 
  Layers, 
  BarChart3, 
  FileText, 
  Award,
  Globe,
  Database
} from 'lucide-react';

interface CarbonAssessmentViewProps {
  project: FarmingProject;
  onBack: () => void;
  onApproveByAuditor?: (projectId: string) => void;
  isAuditorView?: boolean;
}

export const CarbonAssessmentView: React.FC<CarbonAssessmentViewProps> = ({
  project,
  onBack,
  onApproveByAuditor,
  isAuditorView = false
}) => {
  const result = project.assessmentResult;

  if (!result) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-12 text-center text-slate-300">
        <p>No carbon assessment available for this project.</p>
        <button onClick={onBack} className="mt-4 px-4 py-2 bg-slate-800 rounded-lg text-xs">Back</button>
      </div>
    );
  }

  const esp = result.espCompliance;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-[#2D3B2D]">
      
      {/* Top Back Nav */}
      <button
        onClick={onBack}
        className="flex items-center space-x-2 text-xs font-bold text-[#4F6D4F] hover:text-[#3E573E] bg-white border border-[#E2E8DA] px-4 py-2 rounded-2xl shadow-sm transition-colors mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Return to Dashboard</span>
      </button>

      {/* Hero Header */}
      <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#F0F4EC] pb-5">
          <div>
            <div className="flex items-center space-x-3">
              <h1 className="text-2xl font-black text-[#1A261A]">{project.farmName}</h1>
              <span className="text-xs px-3 py-1 rounded-full font-mono bg-[#F0F4EC] text-[#4F6D4F] border border-[#D7E2CF] font-bold">
                ID: {project.id}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1 font-medium">
              Farmer: <span className="text-[#1A261A] font-bold">{project.farmerName}</span> • Location: {project.location} ({project.areaHectares} Ha)
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="bg-[#E9F0E4] border border-[#D7E2CF] rounded-2xl px-4 py-2.5 text-right">
              <p className="text-[10px] text-[#4F6D4F] uppercase font-bold tracking-wider">Verified Carbon Yield</p>
              <p className="text-xl font-black text-[#1A261A] font-mono">{result.netCarbonCreditsYield} tCO2e/year</p>
            </div>
            <div className="bg-[#FAF3E0] border border-[#E6D0B3] rounded-2xl px-4 py-2.5 text-right">
              <p className="text-[10px] text-[#A67B5B] uppercase font-bold tracking-wider">ESP Rating</p>
              <p className="text-xl font-black text-[#A67B5B] font-mono">{esp.espTier} Tier</p>
            </div>
          </div>
        </div>

        {/* Methodology & AI Confidence */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 text-xs">
          <div>
            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-wider">QUANTIFICATION METHOD</p>
            <p className="text-[#2D3B2D] font-bold mt-0.5">{result.methodologyStandard}</p>
          </div>
          <div>
            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-wider">AI CONFIDENCE INDEX</p>
            <p className="text-[#4F6D4F] font-black mt-0.5 flex items-center gap-1 font-mono">
              <Sparkles className="w-3.5 h-3.5" />
              {result.aiConfidenceScore}% Verified
            </p>
          </div>
          <div>
            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-wider">PRIMARY PRACTICE</p>
            <p className="text-[#365336] font-bold mt-0.5">{project.primaryPractice.replace('_', ' ').toUpperCase()}</p>
          </div>
        </div>
      </div>

      {/* Carbon Mass Balance Breakdown & ESP Radial Scores */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        
        {/* Carbon Calculation balance */}
        <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm">
          <h2 className="text-sm font-bold text-[#1A261A] mb-4 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#4F6D4F]" />
            <span>Carbon Emission & Sequestration Balance</span>
          </h2>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-medium">
                <span>Baseline Conventional Emissions:</span>
                <span className="font-mono font-bold text-[#A67B5B]">{result.baselineEmissions} tCO2e</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-2.5 rounded-full overflow-hidden">
                <div className="bg-[#A67B5B] h-full rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-medium">
                <span>Project Regenerative Emissions:</span>
                <span className="font-mono font-bold text-[#769C76]">{result.projectEmissions} tCO2e</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-2.5 rounded-full overflow-hidden">
                <div className="bg-[#769C76] h-full rounded-full" style={{ width: `${Math.round((result.projectEmissions / result.baselineEmissions) * 100)}%` }}></div>
              </div>
            </div>

            <div className="pt-2 border-t border-[#F0F4EC]">
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-bold">
                <span className="text-[#4F6D4F]">Net Carbon Credit Drawdown:</span>
                <span className="font-mono text-[#4F6D4F] text-sm">+{result.netCarbonCreditsYield} tCO2e/yr</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-3 rounded-full overflow-hidden">
                <div className="bg-[#4F6D4F] h-full rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>
          </div>

          <div className="mt-5 p-4 rounded-2xl bg-[#F9FAF8] border border-[#E2E8DA] text-xs space-y-1.5">
            <p className="font-bold text-[#1A261A]">Key AI Agronomist Insights:</p>
            {result.keyInsights.map((insight, idx) => (
              <p key={idx} className="text-gray-600 text-[11px] leading-relaxed font-medium">
                • {insight}
              </p>
            ))}
          </div>
        </div>

        {/* ESP Performance Matrix */}
        <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-[#1A261A] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#4F6D4F]" />
              <span>ESP Criteria Evaluation (0-100)</span>
            </h2>
            <span className="text-xs px-3 py-1 rounded-full bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF] font-bold">
              Total Score: {esp.totalESPScore}/100
            </span>
          </div>

          <div className="space-y-3.5 text-xs">
            <div>
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-semibold">
                <span>Soil Organic Carbon (SOC) Retention</span>
                <span className="font-mono font-bold text-[#4F6D4F]">{esp.soilOrganicCarbonScore}/100</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-2.5 rounded-full overflow-hidden">
                <div className="bg-[#4F6D4F] h-full rounded-full" style={{ width: `${esp.soilOrganicCarbonScore}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-semibold">
                <span>Water Conservation & Runoff Control</span>
                <span className="font-mono font-bold text-[#769C76]">{esp.waterConservationScore}/100</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-2.5 rounded-full overflow-hidden">
                <div className="bg-[#769C76] h-full rounded-full" style={{ width: `${esp.waterConservationScore}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-semibold">
                <span>Biodiversity Index & Shade Flora</span>
                <span className="font-mono font-bold text-[#A67B5B]">{esp.biodiversityIndexScore}/100</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-2.5 rounded-full overflow-hidden">
                <div className="bg-[#A67B5B] h-full rounded-full" style={{ width: `${esp.biodiversityIndexScore}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-semibold">
                <span>Social Equity & Fair Labor Standards</span>
                <span className="font-mono font-bold text-[#365336]">{esp.socialEquityScore}/100</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-2.5 rounded-full overflow-hidden">
                <div className="bg-[#365336] h-full rounded-full" style={{ width: `${esp.socialEquityScore}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#2D3B2D] mb-1 font-semibold">
                <span>Permanence & Reversal Risk Mitigation</span>
                <span className="font-mono font-bold text-[#4F6D4F]">{esp.permanenceRiskScore}/100</span>
              </div>
              <div className="w-full bg-[#F0F4EC] h-2.5 rounded-full overflow-hidden">
                <div className="bg-[#4F6D4F] h-full rounded-full" style={{ width: `${esp.permanenceRiskScore}%` }}></div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* ESP Compliance Notes & Auditor Sign-off Panel */}
      <div className="bg-white border border-[#E2E8DA] rounded-3xl p-6 shadow-sm">
        <h3 className="text-sm font-bold text-[#1A261A] mb-3 flex items-center gap-2">
          <FileText className="w-4 h-4 text-[#4F6D4F]" />
          <span>ESP Compliance Verification Audit Notes</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs mb-5">
          <div className="bg-[#F9FAF8] p-4 rounded-2xl border border-[#E2E8DA]">
            <p className="font-bold text-[#1A261A] mb-2">Verified Standard Checklist:</p>
            <ul className="space-y-1.5 text-gray-600 text-[11px] font-medium">
              {esp.complianceNotes.map((note, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                  <span>{note}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-[#F9FAF8] p-4 rounded-2xl border border-[#E2E8DA]">
            <p className="font-bold text-[#1A261A] mb-2">Recommendation for Gold Upgrade:</p>
            <ul className="space-y-1.5 text-gray-600 text-[11px] font-medium">
              {result.recommendedImprovements.map((rec, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-[#A67B5B] flex-shrink-0 mt-0.5" />
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Auditor Action Button if viewed by Auditor */}
        {isAuditorView && project.status !== 'certified' && onApproveByAuditor && (
          <div className="border-t border-[#F0F4EC] pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <p className="text-xs font-bold text-[#1A261A]">Auditor Digital Signature Ready</p>
              <p className="text-[11px] text-gray-500 font-medium">Minting will issue Carbon NFT Certificate and trigger $AGRI token reward distribution.</p>
            </div>
            <button
              onClick={() => onApproveByAuditor(project.id)}
              className="bg-[#4F6D4F] hover:bg-[#3E573E] text-white font-bold text-xs px-6 py-3 rounded-2xl shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Approve & Mint Carbon Certificate On-Chain</span>
            </button>
          </div>
        )}
      </div>

    </div>
  );
};
