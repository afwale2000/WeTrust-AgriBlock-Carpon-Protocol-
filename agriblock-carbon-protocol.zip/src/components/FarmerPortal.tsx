import React, { useState } from 'react';
import { FarmerProfile, FarmingProject, FarmingPractice } from '../types';
import { 
  Sprout, 
  Sparkles, 
  Award, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  FileText, 
  TrendingUp, 
  Coins, 
  AlertCircle, 
  ShieldCheck, 
  MapPin, 
  Layers, 
  PlusCircle, 
  Download,
  Loader2,
  Share2
} from 'lucide-react';

interface FarmerPortalProps {
  activeFarmer: FarmerProfile;
  projects: FarmingProject[];
  onCreateProject: (project: FarmingProject) => void;
  onClaimReward: (projectId: string, amount: number) => void;
  onSelectProjectForView: (project: FarmingProject) => void;
}

export const FarmerPortal: React.FC<FarmerPortalProps> = ({
  activeFarmer,
  projects,
  onCreateProject,
  onClaimReward,
  onSelectProjectForView
}) => {
  const [showWizard, setShowWizard] = useState(false);
  const [isAssessing, setIsAssessing] = useState(false);

  // New farm form state
  const [farmName, setFarmName] = useState(activeFarmer.farmName);
  const [location, setLocation] = useState(activeFarmer.location);
  const [areaHectares, setAreaHectares] = useState<number>(Math.round(activeFarmer.totalAcreage * 0.404686));
  const [primaryPractice, setPrimaryPractice] = useState<FarmingPractice>('no_till');
  const [additionalPractices, setAdditionalPractices] = useState<FarmingPractice[]>(['cover_cropping']);
  const [soilType, setSoilType] = useState('Loam / Silty Clay');
  const [fertilizerReductionPercent, setFertilizerReductionPercent] = useState<number>(30);
  const [cropTypes, setCropTypes] = useState<string>(activeFarmer.cropTypes.join(', '));

  const farmerProjects = projects.filter(p => p.farmerId === activeFarmer.id);

  // Submit and trigger Gemini API assessment
  const handleRunAssessment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAssessing(true);

    try {
      const response = await fetch('/api/gemini/assess-farm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmName,
          location,
          areaHectares,
          primaryPractice,
          additionalPractices,
          soilType,
          fertilizerReductionPercent,
          cropTypes: cropTypes.split(',').map(s => s.trim()),
          hasWaterConservation: additionalPractices.includes('water_conservation')
        })
      });

      const data = await response.json();
      const assessment = data.assessment;

      const newProject: FarmingProject = {
        id: `PRJ-${Date.now().toString().slice(-6)}`,
        farmerId: activeFarmer.id,
        farmerName: activeFarmer.name,
        farmName,
        location,
        coordinates: activeFarmer.coordinates,
        areaHectares,
        primaryPractice,
        additionalPractices,
        startDate: new Date().toISOString().split('T')[0],
        soilType,
        fertilizerReductionPercent,
        evidenceDocs: ['farm_satellite_telemetry.png', 'fertilizer_log_2026.pdf'],
        status: 'ai_verified',
        assessmentResult: assessment,
        createdAt: new Date().toISOString().split('T')[0]
      };

      onCreateProject(newProject);
      setIsAssessing(false);
      setShowWizard(false);
    } catch (err) {
      console.error(err);
      setIsAssessing(false);
    }
  };

  const toggleAdditionalPractice = (prac: FarmingPractice) => {
    if (additionalPractices.includes(prac)) {
      setAdditionalPractices(additionalPractices.filter(p => p !== prac));
    } else {
      setAdditionalPractices([...additionalPractices, prac]);
    }
  };

  return (
    <div className="min-h-screen pb-16 text-[#2D3B2D]">
      
      {/* Banner / Farmer Header */}
      <div className="bg-white border-b border-[#E2E8DA] py-8 px-4 sm:px-6 lg:px-8 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-[#D7E2CF] border border-[#B5C9A6] flex items-center justify-center text-[#4F6D4F] font-bold text-2xl shadow-sm">
              👨‍🌾
            </div>
            <div>
              <div className="flex items-center space-x-3">
                <h1 className="text-2xl font-black text-[#1A261A] tracking-tight">{activeFarmer.farmName}</h1>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF] flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Verified Farmer
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1 flex items-center gap-2 font-medium">
                <MapPin className="w-3.5 h-3.5 text-[#769C76]" />
                {activeFarmer.location} • {activeFarmer.totalAcreage} Acres ({Math.round(activeFarmer.totalAcreage * 0.404686)} Hectares)
              </p>
            </div>
          </div>

          {/* Stat Cards Header */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="bg-[#F0F4EC] border border-[#D7E2CF] rounded-2xl p-4 shadow-sm">
              <p className="text-[10px] font-bold text-[#769C76] uppercase tracking-widest">Total Carbon Credits</p>
              <p className="text-xl font-black text-[#1A261A] font-mono mt-0.5">{activeFarmer.creditsBalance} <span className="text-xs font-semibold text-gray-400">tCO2e</span></p>
            </div>

            <div className="bg-[#F0F4EC] border border-[#D7E2CF] rounded-2xl p-4 shadow-sm">
              <p className="text-[10px] font-bold text-[#A67B5B] uppercase tracking-widest">$AGRI Tokens</p>
              <p className="text-xl font-black text-[#1A261A] font-mono mt-0.5">{activeFarmer.rewardTokensBalance.toLocaleString()}</p>
            </div>

            <div className="bg-[#2D3B2D] text-white rounded-2xl p-4 shadow-sm col-span-2 sm:col-span-1">
              <p className="text-[10px] font-bold text-[#A7C0A7] uppercase tracking-widest">Rewards Value</p>
              <p className="text-xl font-black text-white font-mono mt-0.5">${activeFarmer.usdtBalance.toLocaleString()} <span className="text-xs font-normal opacity-70">USD</span></p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        
        {/* Action Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-xl font-bold text-[#1A261A] flex items-center gap-2">
              <Sprout className="w-5 h-5 text-[#4F6D4F]" />
              <span>Carbon Farming Projects</span>
            </h2>
            <p className="text-xs text-gray-500">Submit farming practices for AI carbon quantification & ESP reward minting</p>
          </div>

          <button
            onClick={() => setShowWizard(true)}
            className="flex items-center justify-center space-x-2 bg-[#4F6D4F] hover:bg-[#3E573E] text-white font-bold text-sm px-5 py-3 rounded-2xl shadow-sm transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Carbon Assessment</span>
          </button>
        </div>

        {/* Modal Wizard for New Farm Assessment */}
        {showWizard && (
          <div className="fixed inset-0 bg-[#1A261A]/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white border border-[#E2E8DA] rounded-3xl max-w-2xl w-full p-6 shadow-2xl relative text-[#2D3B2D]">
              <div className="flex items-center justify-between pb-4 border-b border-[#E2E8DA] mb-5">
                <div className="flex items-center space-x-2">
                  <div className="p-2.5 rounded-2xl bg-[#E9F0E4] text-[#4F6D4F]">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-[#1A261A]">AI Carbon Farming Assessment</h3>
                    <p className="text-xs text-gray-500">Powered by Gemini 3.6 Flash & TerraTrust ESP Standards</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowWizard(false)}
                  className="text-gray-400 hover:text-[#2D3B2D] text-sm px-3 py-1 rounded-xl bg-[#F0F4EC]"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleRunAssessment} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1">Farm Name</label>
                    <input 
                      type="text" 
                      value={farmName}
                      onChange={e => setFarmName(e.target.value)}
                      required
                      className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-3.5 py-2.5 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1">Location / Region</label>
                    <input 
                      type="text" 
                      value={location}
                      onChange={e => setLocation(e.target.value)}
                      required
                      className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-3.5 py-2.5 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1">Land Area (Hectares)</label>
                    <input 
                      type="number" 
                      min="1"
                      value={areaHectares}
                      onChange={e => setAreaHectares(Number(e.target.value))}
                      required
                      className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-3.5 py-2.5 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1">Soil Classification</label>
                    <input 
                      type="text" 
                      value={soilType}
                      onChange={e => setSoilType(e.target.value)}
                      className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-3.5 py-2.5 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1.5">Primary Regenerative Practice</label>
                  <select 
                    value={primaryPractice}
                    onChange={e => setPrimaryPractice(e.target.value as FarmingPractice)}
                    className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-3.5 py-2.5 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                  >
                    <option value="no_till">No-Till Agriculture (Minimal Soil Disturbance)</option>
                    <option value="cover_cropping">Continuous Cover Cropping (Winter Rye, Legumes)</option>
                    <option value="agroforestry">Agroforestry & Tree Canopy Integration</option>
                    <option value="biochar_application">Biochar & Pyrolysis Soil Amendment</option>
                    <option value="rotational_grazing">Adaptive Multi-Paddock Rotational Grazing</option>
                    <option value="organic_fertilizer">Organic Fertilizer Transition & Compost</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1.5">Additional ESP Practices (Select all that apply)</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'cover_cropping', label: 'Cover Cropping' },
                      { id: 'water_conservation', label: 'Water Retention Basins' },
                      { id: 'biochar_application', label: 'Biochar Enrichment' },
                      { id: 'rotational_grazing', label: 'Rotational Pasture' }
                    ].map(item => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => toggleAdditionalPractice(item.id as FarmingPractice)}
                        className={`text-xs p-2.5 rounded-2xl border text-left transition-all ${
                          additionalPractices.includes(item.id as FarmingPractice)
                            ? 'bg-[#E9F0E4] border-[#4F6D4F] text-[#4F6D4F] font-bold'
                            : 'bg-[#F9FAF8] border-[#E2E8DA] text-gray-500 hover:border-[#D7E2CF]'
                        }`}
                      >
                        {additionalPractices.includes(item.id as FarmingPractice) ? '✓ ' : '+ '}{item.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-bold text-[#2D3B2D]">Chemical Nitrogen Reduction</span>
                    <span className="text-[#4F6D4F] font-bold font-mono">{fertilizerReductionPercent}% Reduced</span>
                  </div>
                  <input 
                    type="range"
                    min="0"
                    max="80"
                    step="5"
                    value={fertilizerReductionPercent}
                    onChange={e => setFertilizerReductionPercent(Number(e.target.value))}
                    className="w-full accent-[#4F6D4F] bg-[#E2E8DA]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#4F6D4F] uppercase tracking-wider mb-1">Crop & Flora Species</label>
                  <input 
                    type="text" 
                    value={cropTypes}
                    onChange={e => setCropTypes(e.target.value)}
                    placeholder="e.g. Corn, Soybeans, Clover"
                    className="w-full bg-[#F9FAF8] border border-[#E2E8DA] rounded-2xl px-3.5 py-2.5 text-xs text-[#2D3B2D] focus:outline-none focus:border-[#4F6D4F]"
                  />
                </div>

                <div className="bg-[#F0F4EC] border border-[#D7E2CF] rounded-2xl p-3.5 flex items-start space-x-3 text-xs text-[#2D3B2D]">
                  <Sparkles className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                  <p>
                    Gemini 3.6 Flash will evaluate satellite imagery telemetry, calculate baseline vs reduced emissions, and benchmark against the <strong>TerraTrust ESP</strong> standard criteria.
                  </p>
                </div>

                <div className="flex items-center justify-end space-x-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowWizard(false)}
                    className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-gray-500 hover:bg-[#F0F4EC]"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={isAssessing}
                    className="flex items-center space-x-2 bg-[#4F6D4F] hover:bg-[#3E573E] text-white font-bold text-xs px-6 py-3 rounded-2xl shadow-sm transition-all disabled:opacity-50"
                  >
                    {isAssessing ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Quantifying Carbon with Gemini AI...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Run AI Assessment</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Farming Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Projects List (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            {farmerProjects.length === 0 ? (
              <div className="bg-white border border-[#E2E8DA] rounded-3xl p-8 text-center shadow-sm">
                <Sprout className="w-12 h-12 text-[#769C76] mx-auto mb-3" />
                <h3 className="text-base font-bold text-[#1A261A]">No Carbon Farming Projects Registered Yet</h3>
                <p className="text-xs text-gray-500 mt-1 max-w-md mx-auto">
                  Register your farm's regenerative practices (no-till, cover crop, agroforestry) to generate certified carbon credits and earn transparent blockchain rewards.
                </p>
                <button
                  onClick={() => setShowWizard(true)}
                  className="mt-4 inline-flex items-center space-x-2 bg-[#4F6D4F] text-white font-bold text-xs px-5 py-2.5 rounded-2xl"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Start First Assessment</span>
                </button>
              </div>
            ) : (
              farmerProjects.map(prj => {
                const isCertified = prj.status === 'certified';
                const isAiVerified = prj.status === 'ai_verified';
                const isPendingAudit = prj.status === 'pending_audit';

                return (
                  <div 
                    key={prj.id} 
                    className="bg-white border border-[#E2E8DA] hover:border-[#B5C9A6] rounded-3xl p-6 transition-all shadow-sm"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F0F4EC] pb-4 mb-4">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-[#1A261A] text-lg">{prj.farmName}</span>
                          <span className="text-[11px] font-mono text-gray-400">({prj.id})</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-0.5 font-medium">
                          {prj.areaHectares} Hectares • Practice: <span className="text-[#4F6D4F] font-bold">{prj.primaryPractice.replace('_', ' ')}</span>
                        </p>
                      </div>

                      {/* Status Pill */}
                      <div className="flex items-center space-x-2">
                        {isCertified && (
                          <span className="bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF] text-xs px-3.5 py-1 rounded-full font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Certified & On-Chain
                          </span>
                        )}
                        {isAiVerified && (
                          <span className="bg-[#F0F4EC] text-[#5E7E5E] border border-[#E2E8DA] text-xs px-3.5 py-1 rounded-full font-bold flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5" />
                            AI Verified (Awaiting Audit)
                          </span>
                        )}
                        {isPendingAudit && (
                          <span className="bg-[#FAF3E0] text-[#A67B5B] border border-[#E6D0B3] text-xs px-3.5 py-1 rounded-full font-bold flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 animate-pulse" />
                            Auditor Review In Progress
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Carbon Sequestration & ESP Metrics */}
                    {prj.assessmentResult && (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#F9FAF8] rounded-2xl p-4 border border-[#E2E8DA] mb-4">
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-[#769C76] font-bold">Net Carbon Yield</p>
                          <p className="text-lg font-black text-[#1A261A] font-mono mt-0.5">
                            {prj.assessmentResult.netCarbonCreditsYield} <span className="text-xs font-normal text-gray-400">tCO2e</span>
                          </p>
                        </div>

                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-[#A67B5B] font-bold">ESP Score</p>
                          <p className="text-lg font-black text-[#2D3B2D] font-mono mt-0.5">
                            {prj.assessmentResult.espCompliance.totalESPScore}/100
                          </p>
                        </div>

                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-[#769C76] font-bold">ESP Tier</p>
                          <span className="inline-block mt-0.5 text-xs font-bold px-2 py-0.5 rounded-full bg-[#E9F0E4] text-[#4F6D4F] border border-[#D7E2CF]">
                            {prj.assessmentResult.espCompliance.espTier} Standard
                          </span>
                        </div>

                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">AI Confidence</p>
                          <p className="text-lg font-black text-[#4F6D4F] font-mono mt-0.5">
                            {prj.assessmentResult.aiConfidenceScore}%
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Progress Pipeline */}
                    <div className="mb-4">
                      <p className="text-[10px] font-bold text-[#769C76] uppercase tracking-widest mb-2">Verification Pipeline</p>
                      <div className="grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="bg-[#E9F0E4] border border-[#D7E2CF] p-2.5 rounded-xl text-[#4F6D4F]">
                          <p className="font-bold">1. AI Assessment</p>
                          <p className="text-[10px] font-semibold text-[#4F6D4F]">Completed ✓</p>
                        </div>

                        <div className={`p-2.5 rounded-xl border ${
                          isCertified || isPendingAudit 
                            ? 'bg-[#E9F0E4] border-[#D7E2CF] text-[#4F6D4F]' 
                            : 'bg-[#FAF3E0] border-[#E6D0B3] text-[#A67B5B]'
                        }`}>
                          <p className="font-bold">2. ESP Audit</p>
                          <p className="text-[10px] font-semibold">{isCertified ? 'Approved ✓' : 'Awaiting Auditor'}</p>
                        </div>

                        <div className={`p-2.5 rounded-xl border ${
                          isCertified 
                            ? 'bg-[#E9F0E4] border-[#D7E2CF] text-[#4F6D4F]' 
                            : 'bg-[#F9FAF8] border-[#E2E8DA] text-gray-400'
                        }`}>
                          <p className="font-bold">3. On-Chain Mint</p>
                          <p className="text-[10px] font-semibold">{isCertified ? 'Mined & Issued ✓' : 'Pending'}</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Footer */}
                    <div className="flex items-center justify-between pt-3 border-t border-[#F0F4EC] text-xs">
                      <button
                        onClick={() => onSelectProjectForView(prj)}
                        className="text-[#4F6D4F] hover:text-[#3E573E] font-bold flex items-center space-x-1"
                      >
                        <span>View Full ESP Audit & Telemetry</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>

                      {isCertified && (
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-400 text-[11px]">Token Hash:</span>
                          <span className="font-mono text-[#4F6D4F] font-bold text-[11px] bg-[#E9F0E4] px-2 py-0.5 rounded-lg border border-[#D7E2CF]">
                            {prj.certificateHash?.slice(0, 10)}...
                          </span>
                        </div>
                      )}
                    </div>

                  </div>
                );
              })
            )}
          </div>

          {/* Right Column: ESP Criteria & Reward Payout Center */}
          <div className="space-y-6">
            
            {/* ESP Criteria card */}
            <div className="bg-[#F0F4EC] border border-[#D7E2CF] rounded-3xl p-6 shadow-sm">
              <div className="flex items-center space-x-2 mb-3">
                <ShieldCheck className="w-5 h-5 text-[#4F6D4F]" />
                <h3 className="text-sm font-bold text-[#4F6D4F] uppercase tracking-widest">ESP Certification Criteria</h3>
              </div>
              <p className="text-xs text-gray-600 mb-4 font-medium">
                To issue carbon credits on TerraTrust Chain, farming operations must satisfy strict Environmental & Social Performance criteria:
              </p>

              <div className="space-y-3 text-xs">
                <div className="flex items-start space-x-2.5 bg-white p-3 rounded-2xl border border-[#E2E8DA]">
                  <CheckCircle2 className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-[#1A261A]">Soil Organic Carbon (SOC)</p>
                    <p className="text-[11px] text-gray-500">Proven continuous increase in SOC via no-till or biochar.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5 bg-white p-3 rounded-2xl border border-[#E2E8DA]">
                  <CheckCircle2 className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-[#1A261A]">Water Impact & Non-Contamination</p>
                    <p className="text-[11px] text-gray-500">At least 20% reduction in synthetic nitrogen fertilizer runoff.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5 bg-white p-3 rounded-2xl border border-[#E2E8DA]">
                  <CheckCircle2 className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-[#1A261A]">Biodiversity & Farmer Social Equity</p>
                    <p className="text-[11px] text-gray-500">Support for native flora/fauna and fair labor compensation.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2.5 bg-white p-3 rounded-2xl border border-[#E2E8DA]">
                  <CheckCircle2 className="w-4 h-4 text-[#4F6D4F] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-[#1A261A]">3rd-Party Verification</p>
                    <p className="text-[11px] text-gray-500">Independent auditor digital sign-off on blockchain ledger.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Smart Contract Reward Claim Box */}
            <div className="bg-[#2D3B2D] text-white rounded-3xl p-6 shadow-sm">
              <div className="flex items-center space-x-2 mb-2">
                <Coins className="w-5 h-5 text-[#A7C0A7]" />
                <h3 className="text-xs font-bold text-[#A7C0A7] uppercase tracking-widest">Reward Balance & Distribution</h3>
              </div>
              <p className="text-xs text-slate-300 mb-4 opacity-90">
                Smart Contract logic calculates rewards based on net tCO2e + ESP tier multiplier.
              </p>

              <div className="bg-white/10 rounded-2xl p-4 space-y-2 text-xs mb-5 font-medium">
                <div className="flex justify-between">
                  <span className="opacity-70">Base Reward Rate:</span>
                  <span className="font-mono font-bold text-white">100 $AGRI / tCO2e</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-70">Gold ESP Tier Bonus:</span>
                  <span className="font-mono font-bold text-[#A7C0A7]">+20% Bonus</span>
                </div>
                <div className="flex justify-between border-t border-white/10 pt-2 font-bold">
                  <span>Connected Wallet:</span>
                  <span className="font-mono text-[#A7C0A7]">{activeFarmer.walletAddress.slice(0, 8)}...</span>
                </div>
              </div>

              <div className="mb-4">
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-3xl font-black">{activeFarmer.rewardTokensBalance.toLocaleString()}</span>
                  <span className="text-xs font-semibold opacity-70 uppercase">$AGRI</span>
                </div>
              </div>

              <button
                onClick={() => alert(`Rewards for ${activeFarmer.name} are synchronized with Web3 Wallet (${activeFarmer.walletAddress})`)}
                className="w-full py-3.5 bg-[#769C76] text-white rounded-2xl font-bold hover:bg-[#5E7E5E] transition-colors shadow-sm text-xs"
              >
                Wallet Synced ✓
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
